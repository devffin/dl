@echo off
title LSE FreeVM
setlocal enabledelayedexpansion
cd /d "%~dp0"
chcp 65001 >nul

:menu
cls
echo ============================================
echo                 LSE FreeVM
echo     Location de VMs légales et gratuites
echo ============================================
echo.
echo 1. Voir les VMs disponibles
echo 2. Louer une VM
echo 3. Mes locations actives
echo 0. Quitter
echo.
set /p choice="Choisissez une option: "

if "%choice%"=="1" goto list_vms
if "%choice%"=="2" goto rent_vm
if "%choice%"=="3" goto my_rentals
if "%choice%"=="0" goto end
echo Option invalide.
pause
goto menu

:list_vms
cls
echo VMs disponibles:
echo.
echo 1. Ubuntu 24.04 LTS Desktop/Server - Pour développement web
echo 2. Windows 10/11 - Pour applications Windows
echo 3. Zorin OS 18 - Pour utilisateurs Linux débutants
echo 4. Fedora 43 - Pour développeurs et testeurs
echo 5. Bientot disponible ...
echo.
echo Toutes les VMs sont gratuites et légales.
pause
goto menu

:rent_vm
cls
echo Ouverture du formulaire de location...
start "" "https://forms.gle/7kd8NjzYbafvQRyM9"
pause
goto menu

:my_rentals
cls
echo Vos locations actives:
echo.
set /p "user_id=Entrez votre nom d'utilisateur: "
set "user_id=%user_id: =%"
set "user_id=%user_id:"=%"
if "%user_id%"=="" (
    echo Nom d'utilisateur vide.
    pause
    goto menu
)
echo Recuperation des locations pour %user_id%...
echo.
set "loc_file=%temp%\locs_%random%_%random%.txt"
set "USER_ID_RAW=%user_id%"
powershell -NoProfile -Command "$u=[uri]::EscapeDataString($env:USER_ID_RAW); $url='https://devffin.github.io/dl/locs/' + $u + '.txt'; try { $null = Invoke-WebRequest -Uri $url -OutFile $env:loc_file -ErrorAction Stop; exit 0 } catch { exit 1 }" >nul 2>nul
if errorlevel 1 (
    echo Aucune location trouvee pour %user_id% ou service indisponible.
) else (
    type "%loc_file%" 2>nul
)
del "%loc_file%" 2>nul
echo.
pause
goto menu

:end
echo Merci d'avoir utilisé LSE FreeVM.
timeout /t 2 >nul
