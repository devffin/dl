@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"
chcp 65001 >nul
title Mise a jour TelService

if not exist config\ mkdir config
if not exist config\updates.txt (
    >config\updates.txt echo 1
)

set "updates="
set /p updates=<config\updates.txt
if /i "!updates!"=="updates=1" set "updates=1"
if /i "!updates!"=="updates=0" set "updates=0"
if "!updates!"=="1 " set "updates=1"
if "!updates!"=="0 " set "updates=0"
if "!updates!"=="" set "updates=1"
if not "!updates!"=="1" if not "!updates!"=="0" set "updates=1"

if "!updates!"=="0" (
    echo Mises a jour desactivees.
    pause
    exit /b
)

echo Verification des mises a jour pour TelService...
powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://devffin.github.io/dl/TS/version.txt' -OutFile 'temp_version.txt'" 2>nul
powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://devffin.github.io/dl/TS/build.txt' -OutFile 'temp_build.txt'" 2>nul

if not exist "temp_version.txt" goto :net_error
if not exist "temp_build.txt" goto :net_error
if not exist "version.txt" (
    echo version.txt introuvable.
    goto :cleanup
)
if not exist "build.txt" (
    echo build.txt introuvable.
    goto :cleanup
)

set /p remote_ver=<temp_version.txt
set /p local_ver=<version.txt
set /p remote_build=<temp_build.txt
set /p local_build=<build.txt

set "update_needed=0"
if /i not "!local_ver!"=="!remote_ver!" set "update_needed=1"
if /i not "!local_build!"=="!remote_build!" set "update_needed=1"

if "!update_needed!"=="0" (
    echo TelService est a jour ^(version !local_ver! / build !local_build!^).
    goto :cleanup
)

echo Mise a jour disponible.
echo Locale : !local_ver! ^(!local_build!^)
echo Distante : !remote_ver! ^(!remote_build!^)
echo Telechargement des fichiers...
powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://devffin.github.io/dl/TS/TS.zip' -OutFile 'TS.zip'" 2>nul
if not exist "TS.zip" (
    echo Echec du telechargement de la mise a jour.
    goto :cleanup
)

echo Extraction de TS.zip...
>upd.bat echo @echo off
>>upd.bat echo powershell -NoProfile -Command "Expand-Archive -Path 'TS.zip' -DestinationPath '.' -Force" 2^>nul
>>upd.bat echo del /q TS.zip 2^>nul
>>upd.bat echo if exist TelService.exe start "" "TelService.exe"
>>upd.bat echo if not exist TelService.exe if exist telservice.bat start "" "telservice.bat"
>>upd.bat echo del /q "%%~f0"
echo Mise a jour terminee. Nouvelle version: !remote_ver! ^(!remote_build!^)
start "" upd.bat
goto :cleanup_fast_exit

:net_error
echo Impossible de verifier les mises a jour. Verifiez votre connexion internet.

:cleanup
if exist temp_version.txt del /q temp_version.txt
if exist temp_build.txt del /q temp_build.txt
if exist TS.zip del /q TS.zip
pause
exit /b

:cleanup_fast_exit
if exist temp_version.txt del /q temp_version.txt
if exist temp_build.txt del /q temp_build.txt
exit /b
