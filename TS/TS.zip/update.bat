@echo off
chcp 65001 >nul
title Mise à jour TelService

if not exist config.txt (
    echo updates=1 > config.txt
)

for /f "tokens=1,2 delims==" %%a in (config.txt) do (
    if "%%a"=="updates" set updates=%%b
)

if "%updates%"=="0" (
    echo Mises à jour désactivées.
    pause
    exit /b
)

echo Vérification des mises à jour pour TelService...
powershell -command "Invoke-WebRequest -Uri 'https://devffin.github.io/dl/TS/version.txt' -OutFile 'temp_version.txt'" 2>nul
powershell -command "Invoke-WebRequest -Uri 'https://devffin.github.io/dl/TS/build.txt' -OutFile 'temp_build.txt'" 2>nul

if exist "temp_version.txt" (
    set /p remote_ver=<temp_version.txt
    set /p local_ver=<version.txt
    set /p remote_build=<temp_build.txt
    set /p local_build=B4
    if "!local_ver!" neq "!remote_ver!" (
        if "!local_build!" neq "!remote_build!" (
            echo Mise à jour disponible. Version locale: !local_ver!, Version distante: !remote_ver!
            echo Téléchargement des mises à jour...
            powershell -command "Invoke-WebRequest -Uri 'https://devffin.github.io/dl/TS/TS.zip' -OutFile 'TS.zip'" 2>nul
            if exist "TS.zip" (
                echo Extraction de TS.zip...
                echo powershell -command "Expand-Archive -Path 'TS.zip' -DestinationPath '.' -Force" 2>nul >upd.bat
                echo del TS.zip >> upd.bat
                echo start "" "TelService.exe" >>> upd.bat
                echo Mise à jour terminée. Nouvelle version: !remote_ver!
                start "" upd.bat
                exit
            ) else (
                echo Échec du téléchargement de la mise à jour.
            )
        )
    ) else (
        echo TelService est à jour (version !local_ver!).
    )
    del temp_version.txt
) else (
    echo Impossible de vérifier les mises à jour. Vérifiez votre connexion internet.
)

pause