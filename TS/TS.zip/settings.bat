@echo off

if exist config\updates.txt (
    set /p updates=<config\updates.txt
) else (
    echo 1>config\updates.txt
    set updates=1
)

if exist config\color.txt (
    set /p color=<config\color.txt
) else (
    echo 0>config\color.txt
    set color=0
)

if "%updates%"=="1" set update_status=Activees
if "%updates%"=="0" set update_status=Desactivees

:settings
cls
echo ==================================================
echo              Parametres de TelService
echo ==================================================
echo.
echo 1. Mises a jour : %update_status%
echo 2. Bientot disponible : Themes et personnalisation
echo 3. Desinstaller TelService
echo 4. A propos de TelService
echo 5. Reinitialiser les parametres
echo.
echo 0. Retour au menu principal
echo.
set /p choice="Selectionnez une option (0/2): "

if "%choice%"=="1" (
    if "%updates%"=="1" (
        echo 0 > config\updates.txt
        set updates=0
        set update_status=Desactivees
    ) else (
        echo 1 > config\updates.txt
        set updates=1
        set update_status=Activees
    )
    echo Mises a jour %update_status%.
    pause
    goto settings
)
if "%choice%"=="2" (
    echo Cette fonctionnalite sera disponible dans une future mise a jour.
    pause
    goto settings
)
if "%choice%"=="3" (
    start "" "TSManager\TSManager.bat" uninstall

    exit
)
if "%choice%"=="4" (
    cls
    echo A propos de TelService
    echo ==================================================
    echo.
    echo TelService 1.1 B4 ^(TEST^) - ^(c^) 2026 devffin
    echo Utilise l'API d'Open-Meteo pour les previsions meteo.
    echo Utilise ascii.live pour l'application ASCIImation.
    echo.
    echo Ce logiciel est en cours de developpement et peut contenir des bugs.
    echo N'hesitez pas a faire part de vos retours et suggestions sur le GitHub du projet.
    echo https://github.com/devffin/TelService
    echo.
    echo Si vous souhaitez avoir une version plus ancienne, vous pouvez me contacter par mail.
    echo contact.diffin@gmail.com ou comptevideo.lse@outlook.com ^(LSE Studios^)
    echo ==================================================
    pause
    goto settings
)
if "%choice%"=="5" (
    del /q config\*.txt
    echo Parametres reinitialises.
    pause
    goto settings
)
if "%choice%"=="0" (
    exit /b
)
echo Option invalide. Veuillez reessayer.
pause
goto settings