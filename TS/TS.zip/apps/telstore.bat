@echo off
title TelStore
setlocal enabledelayedexpansion
chcp 65001 >nul

:MENU
cls
echo.
echo ===============================================
echo              TelService STORE
echo ===============================================
echo.
echo Interruption du service de TelStore.
echo.
echo Du a la complication de la gestion des applications et des mises a jour, TelStore est temporairement suspendu pour une refonte complete.
echo Nous nous excusons pour la gène occasionnée et travaillons activement à une nouvelle version de TelStore qui offrira une meilleure expérience utilisateur et une gestion plus efficace des applications et des mises à jour.
echo Restez à l'écoute pour les mises à jour sur le retour de TelStore.
echo.
echo Merci de votre compréhension.
echo.
pause