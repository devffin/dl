@echo off
setlocal enabledelayedexpansion
chcp 65001 >nul

cd /d "%~dp0"

REM Check for Python
where python >nul 2>nul
if errorlevel 1 (
    echo Installation de Python ...
    powershell -command "Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.12.6/python-3.12.6-amd64.exe' -OutFile 'python_installer.exe'" 2>nul
    if not errorlevel 1 (
        start /wait python_installer.exe /quiet InstallAllUsers=1 PrependPath=1
        del python_installer.exe
        where python >nul 2>nul
        if not errorlevel 1 (
            echo Python installé avec succès.
        ) else (
            echo Python n'a pas été installé correctement. Veuillez l'installer manuellement.
            pause
            exit /b
        )
    ) else (
        echo Erreur lors du téléchargement de Python. Vérifiez votre connexion internet.
        pause
        exit /b
    )
)

:MENU
cls
echo  Musique - Lecteur de musique depuis un lien
echo =============================================
echo.
echo 1. Jouer depuis un lien (YouTube, etc.)
echo 2. Quitter
echo.
set /p choice="Choisissez une option: "

if "%choice%"=="1" goto PLAY
if "%choice%"=="2" exit /b
goto MENU

:PLAY
cls
del temp_music.* 2>nul
del downloaded_before.txt 2>nul

REM Download yt-dlp if not present
if not exist yt-dlp.exe (
    echo Téléchargement de yt-dlp...
    curl -L -o yt-dlp.exe https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe 2>nul
    if errorlevel 1 (
        echo Erreur lors du téléchargement de yt-dlp. Vérifiez votre connexion internet.
        pause
        goto MENU
    )
)

REM Download ffmpeg if not present
if not exist ffmpeg.exe (
    echo Téléchargement de ffmpeg...
    curl -L -o ffmpeg.zip https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip 2>nul
    if errorlevel 1 (
        echo Erreur lors du téléchargement de ffmpeg.
        pause
        goto MENU
    )
    powershell -command "Expand-Archive -Path ffmpeg.zip -DestinationPath . -Force" 2>nul
    if errorlevel 1 (
        echo Erreur lors de l'extraction de ffmpeg.
        del ffmpeg.zip
        pause
        goto MENU
    )
    move "ffmpeg-master-latest-win64-gpl\bin\ffmpeg.exe" . 2>nul
    move "ffmpeg-master-latest-win64-gpl\bin\ffprobe.exe" . 2>nul
    rmdir /s /q "ffmpeg-master-latest-win64-gpl" 2>nul
    del ffmpeg.zip
)

REM Check for spotdl
if not exist spotdl_installed.txt (
    echo Vérification de spotdl...
    python -c "import spotdl" 2>nul
    if errorlevel 1 (
        echo Installation de spotdl...
        python -m pip install spotdl --quiet 2>nul
        if errorlevel 1 (
            echo Erreur lors de l'installation de spotdl.
        ) else (
            echo spotdl installé. > spotdl_installed.txt
        )
    ) else (
        echo spotdl déjà installé. > spotdl_installed.txt
    )
)

echo.
echo Entrez le lien de la musique (YouTube, Spotify, etc.):
set /p url=

if "!url!"=="" (
    echo Aucun lien fourni.
    pause
    goto MENU
)

echo.
echo Traitement du lien...

REM Check for YouTube
call :check_youtube
if !is_youtube!==1 (
    call :download_youtube
    goto MENU
)

REM Check for Spotify
call :check_spotify
if !is_spotify!==1 (
    call :download_spotify
    goto MENU
)

REM Unsupported link
echo Type de lien non supporté. Tentative de lecture directe...
start "" "!url!"

echo.
echo Appuyez sur une touche pour revenir au menu...
pause >nul
goto MENU


:check_youtube
set "is_youtube=0"
if not "!url:youtube.com=!"=="!url!" (
    set "is_youtube=1"
) else if not "!url:youtu.be=!"=="!url!" (
    set "is_youtube=1"
)
exit /b

:check_spotify
set "is_spotify=0"
if not "!url:spotify.com=!"=="!url!" (
    set "is_spotify=1"
)
exit /b

:download_youtube
echo Lien YouTube détecté. Téléchargement et lecture...
yt-dlp -q -x --audio-format mp3 -o "temp_music.%%(ext)s" "!url!" >nul 2>&1
if errorlevel 1 (
    echo Erreur lors du téléchargement.
    del temp_music.* 2>nul
    pause
    exit /b
)

for %%f in (temp_music.*) do (
    echo Lecture de %%f
    start "" "%%f"
    set /p save="Enregistrer ? (O/N) : "
    if /i "!save!"=="O" (
        set /p path="Entrez le chemin de sauvegarde (ex: C:\Musique\) : "
        if not exist "!path!" (
            mkdir "!path!" 2>nul
        )
        set /p filename="Entrez le nom du fichier (sans extension) : "
        set "ext=%%~xf"
        move "%%f" "!path!\!filename!!ext!" 2>nul
        if errorlevel 1 (
            echo Erreur lors de la sauvegarde du fichier.
            del "%%f" 2>nul
        ) else (
            echo Fichier sauvegardé à !path!\!filename!!ext!
        )
    )
)
del temp_music.* 2>nul
exit /b

:download_spotify
echo Lien Spotify détecté. Téléchargement avec spotdl...
(for %%f in (*.mp3 *.m4a *.flac) do @echo %%f) > downloaded_before.txt 2>nul
spotdl "!url!" -q >nul 2>&1
if errorlevel 1 (
    echo Erreur lors du téléchargement.
    del downloaded_before.txt 2>nul
    pause
    exit /b
)
for %%f in (*.mp3 *.m4a *.flac) do (
    findstr /x "%%f" downloaded_before.txt >nul 2>&1
    if errorlevel 1 (
        echo Lecture de %%f
        start "" "%%f"
    )
)
del downloaded_before.txt 2>nul
exit /b
