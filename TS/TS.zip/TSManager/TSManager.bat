@echo off
title TelService Manager
setlocal enabledelayedexpansion
cd /d "%~dp0"

if /i not "%~1"=="" goto :argmode

:main_menu
    echo TSManager - Gestionnaire de TelService
    echo ==================================================
    echo Bienvenue dans le gestionnaire de TelService.
    echo 1. Desinstaller TelService
    echo 2. Aide avec les arguments de ce programme
    echo.
    echo 0. Quitter le gestionnaire
    echo.
    set /p "main_choice=Selectionnez une option (0/2) : "
    if "%main_choice%"=="1" (
        start "" "%~f0" uninstall
        exit /b
    )
    if "%main_choice%"=="2" (
        start "" "%~f0" help
        exit /b
    )
    if "%main_choice%"=="0" exit /b
    goto main_menu

:argmode
if /i "%~1"=="uninstall" (
    for %%I in ("%~dp0..") do set "install_dir=%%~fI"
    color 4
    echo Confirmation de desinstallation de TelService
    echo ==================================================
    echo Vous etes sur le point de desinstaller TelService de votre systeme.
    echo Cette action est irreversible et supprimera les fichiers de TelService.
    echo.
    set /p "confirm=Voulez-vous continuer ? (O/N) : "
    if /i "!confirm!"=="N" (
        echo Desinstallation annulee.
        timeout /t 2 >nul
        exit /b
    )
    if /i not "!confirm!"=="O" (
        echo Reponse invalide.
        timeout /t 2 >nul
        exit /b 1
    )

    call :requireAdmin uninstall
    if errorlevel 2 exit /b
    if errorlevel 1 (
        echo Elevation annulee. Operation interrompue.
        timeout /t 2 >nul
        exit /b 1
    )

    cls
    color 7
    echo Choix du mode de desinstallation
    echo ==================================================
    echo 1. Desinstallation GUI
    echo 2. Desinstallation CMD
    echo ==================================================
    echo.
    set /p "mode=Selectionnez une option (1/2) : "

    if "%mode%"=="1" (
        if exist "%install_dir%\unins000.exe" (
            start "" "%install_dir%\unins000.exe"
            exit /b
        ) else (
            echo Aucun desinstalleur GUI trouve dans "%install_dir%".
            pause
            exit /b 1
        )
    )

    if "%mode%"=="2" (
        echo Desinstallation en cours ...
        >"%temp%\uninstall.cmd" echo rmdir /s /q "%install_dir%"
        start "" "%temp%\uninstall.cmd"
        exit /b
    )

    echo Mode invalide.
    exit /b 1
)

if /i "%~1"=="install" (
    echo ERREUR : Ce script est uniquement destine a la gestion de TelService.
    echo Pour installer TelService, veuillez executer le setup d'installation.
    echo https://github.com/devffin/TelService/releases
    pause
    exit /b
)

if /i "%~1"=="help" (
    echo Usage : TSManager.bat [option]
    echo.
    echo Options :
    echo   install     - Installer TelService (non supporte par ce script)
    echo   uninstall   - Desinstaller TelService
    echo   help        - Afficher ce message d'aide
    echo.
    echo Si aucune option n'est fournie, le menu principal s'ouvre.
    pause
    exit /b
)

echo Argument invalide: %~1
exit /b 1

:requireAdmin
net session >nul 2>&1
if not errorlevel 1 exit /b 0
powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -ArgumentList '%~1' -Verb RunAs"
if errorlevel 1 exit /b 1
exit /b 2
