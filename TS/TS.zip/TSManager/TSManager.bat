@echo off
title TelService Manager
setlocal enabledelayedexpansion

if /i "%1"=="" (
    echo TSManager - Gestionnaire de TelService
    echo ==================================================
    echo Bienvenue dans le gestionnaire de TelService.
    echo Ici, vous pouvez configurer les parametres de TelService, desinstaller le logiciel ou en savoir plus a son sujet.
    echo.
    echo 1. Desinstaller TelService
    echo 2. Aide avec les arguments de ce programme
    echo.
    echo 0. Quitter le gestionnaire
    echo.
    set /p "main_choice=Selectionnez une option (0/2) : "
    if "%main_choice%"=="1" (
        start "" "TSManager\TSManager.bat uninstall"
        exit
    )
    if "%main_choice%"=="2" (
        start "" "TSManager\TSManager.bat help"
        exit
    )
    if "%main_choice%"=="0" (
        exit
    )
    exit
)

if /i "%1"=="uninstall" (
    set "install_dir=%cd%\.."
    color 4
    echo Confirmation de desinstallation de TelService
    echo ==================================================
    echo Vous etes sur le point de desinstaller TelService de votre systeme.
    echo Cette action est irreversible et supprimera tous les fichiers de TelService.
    echo.
    set /p "confirm=Voulez-vous continuer ? (O/N) : "
    if /i "!confirm!"=="O" (
        color 7
        echo Elevation des privileges pour la desinstallation ...
        call :requireAdmin
        if errorlevel 1 (
            echo Elevation annulee. Operation interrompue.
            timeout /t 2 >nul
            exit /b 1
        )
        cls
        echo Choix du mode de desinstallation
        echo ==================================================
        echo.
        echo 1. Desinstallation GUI
        echo 2. Desinstallation CMD
        echo ==================================================
        echo.
        set /p "mode=Selectionnez une option (1/2) : "
        if "%mode%"=="1" (
            start "" "%install_dir%\unins000.exe"
            if exist "%install_dir%\unins*.exe" (
                echo ATTENTION : Apres la desinstallation, veuillez supprimer manuellement le dossier TelService dans Program Files.
                timeout /t 5 >nul
            )
            exit
        )
        if "%mode%"=="2" (
            echo Desinstallation en cours ...
            echo rmdir /s /q "%install_dir%" > "%temp%\uninstall.cmd"
            start "" "%temp%\uninstall.cmd"
            exit
        )
    )
    if /i "!confirm!"=="N" (
        echo Desinstallation annulee.
        timeout /t 2 >nul
        exit
    )
)

if /i "%1"=="install" (
    echo ERREUR : Ce script est uniquement destine a la gestion de TelService.
    echo Pour installer TelService, veuillez executer le setup d'installation.
    echo https://github.com/devffin/TelService/releases
    pause
    exit
)

if /i "%1"=="help" (
    echo Usage : TSManager.bat [option]
    echo.
    echo Options :
    echo   install     - Installer TelService (non supporte par ce script)
    echo   uninstall   - Desinstaller TelService
    echo   help        - Afficher ce message d'aide
    echo.
    echo Si aucune option n'est fournie, le gestionnaire de parametres s'ouvrira.
    pause
    exit
)