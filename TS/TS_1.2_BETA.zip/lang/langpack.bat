@echo off
rem LangPack loader: sets variables directly for the current language.
rem Supports language pack folders (%~dp0packs\LangPack_<lang>\LangPack.txt),
rem legacy language files (%~dp0packs\LangPack_<lang>.txt), and the monolithic %~dp0LangPack.txt.

set "packroot=%~dp0packs"
rem Determine language setting via config\lang.txt override, default FR
set "lang=FR"
if exist "%~dp0..\config\lang.txt" (
    for /f "tokens=2 delims==" %%A in ('type "%~dp0..\config\lang.txt" ^| findstr /i "^language"') do (
        set "lang=%%A"
    )
)
set "lang=!lang: =!"

rem Prefer folder-based language pack first.
set "langpack=%packroot%\LangPack_!lang!\LangPack.txt"
if not exist "%langpack%" set "langpack=%packroot%\LangPack_!lang!.txt"
if not exist "%langpack%" set "langpack=%~dp0LangPack.txt"
if not exist "%langpack%" set "langpack=%~dp0..\LangPack.txt"
if not exist "%langpack%" (
    echo LangPack not found in %~dp0 or parent folder. 1>&2
    exit /b 1
)

rem Load values.
set "has_section=0"
set "in_section=0"
for /f "usebackq tokens=*" %%L in ("%langpack%") do (
    set "line=%%L"
    if "!line:~0,1!"=="[" if "!line:~-1!"=="]" (
        set "has_section=1"
        set "section=!line:~1,-1!"
        if "!section!"=="!lang!" (
            set "in_section=1"
        ) else if "!section:~2!"=="" (
            set "in_section=0"
        )
    ) else if "!has_section!"=="0" (
        for /f "tokens=1* delims== " %%A in ("!line!") do (
            set "key=%%A"
            set "value=%%B"
            if not "!key!"=="" if not "!key:~0,1!"=="#" if not "!value!"=="" set "!key!=!value!"
        )
    ) else if "!in_section!"=="1" (
        for /f "tokens=1* delims== " %%A in ("!line!") do (
            set "key=%%A"
            set "value=%%B"
            if not "!key!"=="" if not "!key:~0,1!"=="#" if not "!value!"=="" set "!key!=!value!"
        )
    )
)

exit /b 0