@echo off
title myAIRBENZ
setlocal enabledelayedexpansion
chcp 65001 >nul
call ..\lang\langpack.bat

if not exist "..\config\lang.txt" (
    if not exist "..\config" mkdir "..\config"
    call :detect_os_language
    echo language=!detected_language!>"..\config\lang.txt"
)

call ..\lang\langpack.bat

:menu
cls
echo.
echo ====================================================
echo !airb_welcome!
echo !airb_subtitle!
echo ====================================================
echo.
echo ====================================================
echo !airb_news!
echo.
powershell -command "Invoke-WebRequest -Uri 'https://devffin.github.io/dl/ma-actus.txt' -OutFile '%temp%\actus.txt'" 2>nul
if errorlevel 1 (
    echo !airb_error_download!
)
type "%temp%\actus.txt" 2>nul || echo !airb_no_news!
del "%temp%\actus.txt" 2>nul
echo.
echo ====================================================
echo.
echo !airb_press_key!
pause >nul
exit /b 0

:: Version 1.3 (2026-04-03)
