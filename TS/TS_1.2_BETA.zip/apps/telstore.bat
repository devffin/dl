@echo off
title TelStore
setlocal enabledelayedexpansion
chcp 65001 >nul
call ..\lang\langpack.bat

if not exist "..\config\lang.txt" (
    if not exist "..\config" mkdir "..\config"
    call :detect_os_language
    echo language=!detected_language!>"..\config\lang.txt"
)

call ..\lang\langpack.bat

:MENU
cls
echo.
echo ===============================================
echo              !ts_title!
echo ===============================================
echo.
echo !ts_maintenance!
echo.
echo !ts_reason!
echo !ts_apology!
echo !ts_staying_tuned!
echo.
echo !ts_thank_you!
echo.
pause

exit /b

:: Version 1.2.0-I (2026-04-03)
