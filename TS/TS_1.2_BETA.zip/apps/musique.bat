@echo off
title Musique
setlocal enabledelayedexpansion
chcp 65001 >nul
call ..\lang\langpack.bat

cd /d "%~dp0"

REM Create parent config if needed
if not exist "..\config\lang.txt" (
    if not exist "..\config" mkdir "..\config"
    call :detect_os_language
    echo language=!detected_language!>"..\config\lang.txt"
)

REM Load language
call ..\lang\langpack.bat

REM Check for Python
where python >nul 2>nul
if errorlevel 1 (
    echo !music_python_required!
    set /p pyinstall="!music_install_python_yn!: "
    if /i "!pyinstall!"=="O" (
        echo !music_installing_python!...
        powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.12.6/python-3.12.6-amd64.exe' -OutFile 'python_installer.exe'" 2>nul
        if not errorlevel 1 (
            start /wait python_installer.exe /quiet InstallAllUsers=1 PrependPath=1
            del python_installer.exe
            where python >nul 2>nul
            if not errorlevel 1 (
                echo !music_python_success!
            ) else (
                echo !music_python_error!
                pause
                exit /b
            )
        ) else (
            echo !music_download_error!
            pause
            exit /b
        )
    ) else (
        echo !music_install_cancelled!
        pause
        exit /b
    )
)

:MENU
cls
echo  !music_player_title!
echo =============================================
echo.
echo 1. !music_play_from_link!
echo 2. !music_quit!
echo.
set /p choice="!music_choose_option!: "

if "%choice%"=="1" goto PLAY
if "%choice%"=="2" exit /b
goto MENU

:PLAY
cls
del temp_music.* 2>nul
del downloaded_before.txt 2>nul

REM Download yt-dlp if not present
if not exist yt-dlp.exe (
    echo !music_downloading_ytdlp!...
    curl -L -o yt-dlp.exe https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe 2>nul
    if errorlevel 1 (
        echo !music_ytdlp_error!
        pause
        goto MENU
    )
)

REM Download ffmpeg if not present
if not exist ffmpeg.exe (
    echo !music_downloading_ffmpeg!...
    curl -L -o ffmpeg.zip https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip 2>nul
    if errorlevel 1 (
        echo !music_ffmpeg_error!
        pause
        goto MENU
    )
    powershell -command "Expand-Archive -Path ffmpeg.zip -DestinationPath . -Force" 2>nul
    if errorlevel 1 (
        echo !music_ffmpeg_extract_error!
        del ffmpeg.zip
        pause
        goto MENU
    )
    set "ffmpeg_dir="
    for /d %%D in ("ffmpeg-*") do (
        if exist "%%~fD\bin\ffmpeg.exe" set "ffmpeg_dir=%%~fD"
    )
    if not defined ffmpeg_dir (
        echo !music_ffmpeg_folder_error!
        del ffmpeg.zip
        pause
        goto MENU
    )
    move "!ffmpeg_dir!\bin\ffmpeg.exe" . 2>nul
    move "!ffmpeg_dir!\bin\ffprobe.exe" . 2>nul
    rmdir /s /q "!ffmpeg_dir!" 2>nul
    del ffmpeg.zip
)

REM Check for spotdl
echo Verification de spotdl...
python -c "import spotdl" 2>nul
if errorlevel 1 (
    echo Installation de spotdl...
    python -m pip install spotdl --quiet 2>nul
    if errorlevel 1 (
        echo Erreur lors de l'installation de spotdl.
    )
)

echo.
echo Entrez le lien de la musique (YouTube, Spotify, etc.):
set /p url=

if "!url!"=="" (
    echo Aucun lien fourni.
    pause
    goto MENU
)

echo.
echo Traitement du lien...

REM Check for YouTube
call :check_youtube
if !is_youtube!==1 (
    call :download_youtube
    goto MENU
)

REM Check for Spotify
call :check_spotify
if !is_spotify!==1 (
    call :download_spotify
    goto MENU
)

REM Unsupported link
echo Type de lien non supporté. Tentative de lecture directe...
start "" "!url!"

echo.
echo Appuyez sur une touche pour revenir au menu...
pause >nul
goto MENU


:check_youtube
set "is_youtube=0"
if not "!url:youtube.com=!"=="!url!" (
    set "is_youtube=1"
) else if not "!url:youtu.be=!"=="!url!" (
    set "is_youtube=1"
)
exit /b

:check_spotify
set "is_spotify=0"
if not "!url:spotify.com=!"=="!url!" (
    set "is_spotify=1"
)
exit /b

:download_youtube
echo !music_youtube_detected! !music_downloading!...
yt-dlp -q -x --audio-format mp3 -o "temp_music.%%(ext)s" "!url!" >nul 2>&1
if errorlevel 1 (
    echo !music_download_error_msg!
    del temp_music.* 2>nul
    pause
    exit /b
)

for %%f in (temp_music.*) do (
    echo !music_playing! %%f
    start "" "%%f"
    set /p save="!music_save_yn!: "
    if /i "!save!"=="O" (
        set /p path="!music_save_path!: "
        if not exist "!path!" (
            mkdir "!path!" 2>nul
        )
        set /p filename="!music_save_filename!: "
        set "ext=%%~xf"
        move "%%f" "!path!\!filename!!ext!" 2>nul
        if errorlevel 1 (
            echo !music_save_error!
            del "%%f" 2>nul
        ) else (
            echo !music_saved_at! !path!\!filename!!ext!
        )
    )
)
del temp_music.* 2>nul
exit /b

:download_spotify
echo !music_spotify_detected! !music_downloading_spotdl!...
(for %%f in (*.mp3 *.m4a *.flac) do @echo %%f) > downloaded_before.txt 2>nul
spotdl "!url!" -q >nul 2>&1
if errorlevel 1 (
    echo !music_download_error_msg!
    del downloaded_before.txt 2>nul
    pause
    exit /b
)
for %%f in (*.mp3 *.m4a *.flac) do (
    findstr /x "%%f" downloaded_before.txt >nul 2>&1
    if errorlevel 1 (
        echo !music_playing! %%f
        start "" "%%f"
    )
)
del downloaded_before.txt 2>nul
exit /b

:: Version 1.3 (2026-04-03)
