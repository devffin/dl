@echo off
title Meteo
setlocal enabledelayedexpansion
chcp 65001 >nul
call ..\lang\langpack.bat

REM Configuration
set "CONFIG_FILE=%~dp0meteo_config.txt"

REM Create parent config if needed
if not exist "..\config\lang.txt" (
    if not exist "..\config" mkdir "..\config"
    call :detect_os_language
    echo language=!detected_language!>"..\config\lang.txt"
)

REM Charger la langue
call ..\lang\langpack.bat

REM Charger la ville mémorisée
set "CITY=Paris"
if exist "%CONFIG_FILE%" (
    for /f "delims=" %%a in ('type "%CONFIG_FILE%"') do (
        set "CITY=%%a"
    )
)

:MENU
cls
echo.
echo =============================================
echo           !meteo_title!
echo =============================================
echo.
echo !meteo_current_city!: %CITY%
echo.
echo 1. !meteo_view_weather! %CITY%
echo 2. !meteo_change_city!
echo 3. !meteo_quit!
echo.
set /p "CHOICE=!meteo_choose_option! (1-3): "

if "%CHOICE%"=="1" goto METEO
if "%CHOICE%"=="2" goto CHANGECITY
if "%CHOICE%"=="3" goto END
echo.
echo !meteo_invalid_option!
timeout /t 2 >nul
goto MENU

:CHANGECITY
cls
echo.
echo ====================================
echo           !meteo_change_city_title!
echo ====================================
echo.
echo !meteo_popular_cities!: Paris, Lyon, Marseille, Toulouse, Nice, Bordeaux
echo.
set /p "NEWCITY=!meteo_enter_city!: "

if "%NEWCITY%"=="" (
    echo Nom vide, retour au menu...
    timeout /t 2 >nul
    goto MENU
)

REM Vérifier que la ville existe
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0meteo_check.ps1" "%NEWCITY%"

if !errorlevel! equ 0 (
    echo %NEWCITY%> "%CONFIG_FILE%"
    set "CITY=%NEWCITY%"
    echo.
    echo Ville sauvegardee!
    timeout /t 2 >nul
    goto MENU
) else (
    echo.
    echo Appuyez sur une touche...
    pause >nul
    goto CHANGECITY
)

:METEO
cls
echo.
echo =============================================
echo           !meteo_title!
echo =============================================
echo.
echo !meteo_retrieving_data!: %CITY%
echo.

REM Appel API via PowerShell
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0meteo_get.ps1" "%CITY%"

echo.
echo ===============================================
echo !meteo_press_key_continue!
pause >nul
goto MENU

:END
echo.
echo !meteo_goodbye!
echo.

:: Version 1.2 (2026-04-03)
