@echo off
title ASCIImation 1.1
setlocal
chcp 65001 >nul
call ..\lang\langpack.bat

:Menu
cls
echo.
echo ASCIImation 1.1 - (c) devffin 2026
echo ======================================
echo.
echo 1. Bombe
echo 2. Piece
echo 3. Donut
echo 4. DVD
echo 5. Terre
echo 6. Inde
echo 7. Maxwell
echo 8. Nyan Cat
echo 9. Perroquet
echo.
echo Page 1/2 (N) Suivant
echo ======================================
echo.
set /p choice=Choisissez une animation (1-9) ou 0 pour quitter: 
if "%choice%"=="1" call :run_anim bomb & goto Menu
if "%choice%"=="2" call :run_anim coin & goto Menu
if "%choice%"=="3" call :run_anim donut & goto Menu
if "%choice%"=="4" call :run_anim dvd & goto Menu
if "%choice%"=="5" call :run_anim earth & goto Menu
if "%choice%"=="6" call :run_anim india & goto Menu
if "%choice%"=="7" call :run_anim maxwell & goto Menu
if "%choice%"=="8" call :run_anim nyan & goto Menu
if "%choice%"=="9" call :run_anim parrot & goto Menu
if "%choice%"=="0" exit /b
if /i "%choice%"=="N" goto Menu2
goto Menu

:Menu2
cls
echo.
echo ASCIImation 1.1 - (c) devffin 2026
echo ======================================
echo.
echo 10. Rickroll
echo.
echo Animations : ascii.live
echo Page 2/2 (P) Precedent
echo ======================================
echo.
set /p choice=Choisissez une animation (10) ou 0 pour quitter: 
if "%choice%"=="10" call :run_anim rick & goto Menu2
if "%choice%"=="0" exit /b
if /i "%choice%"=="P" goto Menu
goto Menu2

:run_anim
echo Lancement de l'animation...
echo Faites CTRL+C pour arreter l'animation.
timeout /t 1 >nul
curl ascii.live/%~1
echo.
pause
exit /b

:: Version 1.1
