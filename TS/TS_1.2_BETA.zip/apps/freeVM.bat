@echo off
title LSE FreeVM
setlocal enabledelayedexpansion
cd /d "%~dp0"
chcp 65001 >nul
call ..\lang\langpack.bat

REM Create parent config if needed
if not exist "..\config\lang.txt" (
    if not exist "..\config" mkdir "..\config"
    call :detect_os_language
    echo language=!detected_language!>"..\config\lang.txt"
)

REM Load language
call ..\lang\langpack.bat

rem Fallback options if not defined in language pack
if "!vm_option_1!"=="" set "vm_option_1=!vm_1!"
if "!vm_option_2!"=="" set "vm_option_2=!vm_2!"
if "!vm_option_3!"=="" set "vm_option_3=!vm_3!"
if "!vm_option_0!"=="" set "vm_option_0=!vm_quit!"

:menu
cls
echo ============================================
echo                 !vm_title!
echo                 !vm_subtitle!
echo ============================================
echo.
echo 1. !vm_option_1!
echo 2. !vm_option_2!
echo 3. !vm_option_3!
echo 0. !vm_option_0!
echo.
set /p choice="!vm_choose!: "

if "%choice%"=="1" goto list_vms
if "%choice%"=="2" goto rent_vm
if "%choice%"=="3" goto my_rentals
if "%choice%"=="0" exit /b
echo !vm_invalid!
pause
goto menu

:list_vms
cls
echo !vm_list_title!
echo.
echo 1. !vm_1!
echo 2. !vm_2!
echo 3. !vm_3!
echo 4. !vm_4!
echo 5. !vm_5!
echo.
echo !vm_legal!
pause
goto menu

:rent_vm
cls
echo !vm_rent_msg!
start "" "https://forms.gle/7kd8NjzYbafvQRyM9"
pause
goto menu

:my_rentals
cls
echo !vm_rentals_title!
echo.
set /p choice="!vm_enter_username!: "
set "user_id=%choice: =%"
set "user_id=%user_id:"=%"
if "%user_id%"=="" (
    echo !vm_empty_username!
    pause
    goto menu
)
echo !vm_retrieving_rentals! %user_id%...
echo.
set "loc_file=%temp%\locs_%random%_%random%.txt"
set "USER_ID_RAW=%user_id%"
powershell -NoProfile -Command "$u=[uri]::EscapeDataString($env:USER_ID_RAW); $url='https://devffin.github.io/dl/locs/' + $u + '.txt'; try { $null = Invoke-WebRequest -Uri $url -OutFile $env:loc_file -ErrorAction Stop; exit 0 } catch { exit 1 }" >nul 2>nul
if errorlevel 1 (
    echo !vm_no_rental! %user_id% !vm_or_unavailable!
) else (
    type "%loc_file%" 2>nul
)
del "%loc_file%" 2>nul
echo.
pause
goto menu

:: Version 1.4 (2026-04-03)
