@echo off
title TelService Manager
setlocal enabledelayedexpansion
cd /d "%~dp0"
call ..\lang\langpack.bat

if /i not "%~1"=="" goto :argmode

if not exist "..\config\lang.txt" (
    call :detect_os_language
    echo language=!detected_language!>"..\config\lang.txt"
)

call ..\lang\langpack.bat

:main_menu
    echo !tsm_title!
    echo ==================================================
    echo !tsm_welcome!
    echo 1. !tsm_uninstall!
    echo 2. !tsm_help_option!
    echo.
    echo 0. !tsm_exit!
    echo.
    set /p "main_choice=!tsm_select_option! (0/2) : "
    if "%main_choice%"=="1" (
        start "" "%~f0" uninstall
        exit /b
    )
    if "%main_choice%"=="2" (
        start "" "%~f0" help
        exit /b
    )
    if "%main_choice%"=="0" exit /b
    goto main_menu

:argmode
if /i "%~1"=="uninstall" (
    for %%I in ("%~dp0..") do set "install_dir=%%~fI"
    color 4
    echo !tsm_uninstall_confirm!
    echo ==================================================
    echo !tsm_uninstall_warning!
    echo !tsm_uninstall_irreversible!
    echo.
    set /p "confirm=!tsm_continue_yn!: "
    if /i "!confirm!"=="N" (
        echo !tsm_uninstall_cancelled!
        timeout /t 2 >nul
        exit /b
    )
    if /i not "!confirm!"=="O" (
        if /i not "!confirm!"=="Y" (
            echo !tsm_invalid_response!
            timeout /t 2 >nul
            exit /b 1
        )
    )

    call :requireAdmin uninstall
    if errorlevel 2 exit /b
    if errorlevel 1 (
        echo !tsm_elevation_cancelled!
        timeout /t 2 >nul
        exit /b 1
    )

    start "" "..\unins000.exe"
    exit /b 1
)

if /i "%~1"=="install" (
    echo !tsm_error_install!
    echo !tsm_use_setup!
    echo https://github.com/devffin/TelService/releases
    pause
    exit /b
)

if /i "%~1"=="help" (
    echo !tsm_usage!: TSManager.bat [!tsm_option_label!]
    echo.
    echo !tsm_options!:
    echo   install     - !tsm_install_app! (não suportado por este script^)
    echo   uninstall   - !tsm_uninstall_app!
    echo   help        - !tsm_show_help!
    echo.
    echo !tsm_no_option_menu!
    pause
    exit /b
)

if /i "%~1"=="update" (
    if not exist config\ mkdir config
    if not exist config\updates.txt echo 1>config\updates.txt
    if not exist "config\lang.txt" echo language=FR>config\lang.txt

    call ..\lang\langpack.bat

    set "updates="
    set /p updates=<config\updates.txt
    set "updates=!updates: =!"
    if /i "!updates!"=="updates=1" set "updates=1"
    if /i "!updates!"=="updates=0" set "updates=0"
    if /i not "!updates!"=="1" if /i not "!updates!"=="0" set "updates=1"

    if "!updates!"=="0" (
        echo !tsm_updates_disabled!
        pause
        exit /b
    )

    echo !tsm_checking_updates!...
    for %%X in (version build) do (
        powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://devffin.github.io/dl/TS/%%X.txt' -OutFile 'temp_%%X.txt'" 2>nul
        if not exist "temp_%%X.txt" goto :net_error
    )

    if not exist "version.txt" (
        echo !tsm_version_not_found!
        goto :cleanup
    )
    if not exist "build.txt" (
        echo !tsm_build_not_found!
        goto :cleanup
    )

    set /p remote_ver=<temp_version.txt
    set /p local_ver=<version.txt
    set /p remote_build=<temp_build.txt
    set /p local_build=<build.txt

    set "update_needed=0"
    if /i not "!local_ver!"=="!remote_ver!" set "update_needed=1"
    if /i not "!local_build!"=="!remote_build!" set "update_needed=1"

    if "!update_needed!"=="0" (
        echo !tsm_up_to_date! ^(v!local_ver! / !local_build!^).
        goto :cleanup
    )

    echo !tsm_update_available!
    echo !tsm_local!: !local_ver! ^(!local_build!^)
    echo !tsm_remote!: !remote_ver! ^(!remote_build!^)
    echo !tsm_downloading!...
    powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://devffin.github.io/dl/TS/TS.zip' -OutFile 'TS.zip'" 2>nul
    if not exist "TS.zip" (
        echo !tsm_download_failed!
        goto :cleanup
    )

    echo !tsm_extracting!...
    >upd.bat echo @echo off
    >>upd.bat echo powershell -NoProfile -Command "Expand-Archive -Path 'TS.zip' -DestinationPath '.' -Force" 2^>nul
    >>upd.bat echo del /q TS.zip 2^>nul
    >>upd.bat echo if exist TelService.exe start "" "TelService.exe"
    >>upd.bat echo if not exist TelService.exe if exist telservice.bat start "" "telservice.bat"
    >>upd.bat echo del /q "%%~f0"
    echo !tsm_update_complete! v!remote_ver! ^(!remote_build!^)
    start "" upd.bat
    goto :cleanup_fast_exit
)

echo Argument invalide: %~1
exit /b 1

:requireAdmin
net session >nul 2>&1
if not errorlevel 1 exit /b 0
powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -ArgumentList '%~1' -Verb RunAs"
if errorlevel 1 exit /b 1
exit /b 2

:net_error
echo !tsm_update_check_failed!

:cleanup
if exist temp_version.txt del /q temp_version.txt
if exist temp_build.txt del /q temp_build.txt
if exist TS.zip del /q TS.zip
pause
exit /b

:cleanup_fast_exit
if exist temp_version.txt del /q temp_version.txt
if exist temp_build.txt del /q temp_build.txt
exit /b

