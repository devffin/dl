REM Fichier de traductions centralisées pour TelService
REM A inclure dans tous les scripts batch via: call "..\config\languages.bat"

:load_all_languages
setlocal enabledelayedexpansion
set "lang=FR"
if exist "..\config\lang.txt" (
    for /f "tokens=2 delims==" %%A in ('type ..\config\lang.txt ^| findstr /i "^language"') do (
        set "lang=%%A"
    )
)
set "lang=!lang: =!"

if /i "!lang!"=="EN" goto :lang_EN
if /i "!lang!"=="ES" goto :lang_ES
if /i "!lang!"=="DE" goto :lang_DE
if /i "!lang!"=="IT" goto :lang_IT
if /i "!lang!"=="PT" goto :lang_PT
if /i "!lang!"=="RU" goto :lang_RU
if /i "!lang!"=="JA" goto :lang_JA
if /i "!lang!"=="ZH" goto :lang_ZH
if /i "!lang!"=="NL" goto :lang_NL
if /i "!lang!"=="PL" goto :lang_PL

:lang_FR
set "common_welcome=Bienvenue"
set "common_exit=Quitter"
set "common_back=Retour"
set "common_invalid=Option invalide"
set "common_error=Erreur"
set "common_success=Succes"
set "common_loading=Chargement..."
set "common_goodbye=Au revoir!"
endlocal & exit /b

:lang_EN
set "common_welcome=Welcome"
set "common_exit=Exit"
set "common_back=Back"
set "common_invalid=Invalid option"
set "common_error=Error"
set "common_success=Success"
set "common_loading=Loading..."
set "common_goodbye=Goodbye!"
endlocal & exit /b

:lang_ES
set "common_welcome=Bienvenido"
set "common_exit=Salir"
set "common_back=Atrás"
set "common_invalid=Opción inválida"
set "common_error=Error"
set "common_success=Exito"
set "common_loading=Cargando..."
set "common_goodbye=¡Adiós!"
endlocal & exit /b

:lang_DE
set "common_welcome=Willkommen"
set "common_exit=Beenden"
set "common_back=Zurück"
set "common_invalid=Ungültige Option"
set "common_error=Fehler"
set "common_success=Erfolg"
set "common_loading=Wird geladen..."
set "common_goodbye=Auf Wiedersehen!"
endlocal & exit /b

:lang_IT
set "common_welcome=Benvenuto"
set "common_exit=Esci"
set "common_back=Indietro"
set "common_invalid=Opzione non valida"
set "common_error=Errore"
set "common_success=Successo"
set "common_loading=Caricamento..."
set "common_goodbye=Arrivederci!"
endlocal & exit /b

:lang_PT
set "common_welcome=Bem-vindo"
set "common_exit=Sair"
set "common_back=Voltar"
set "common_invalid=Opção inválida"
set "common_error=Erro"
set "common_success=Sucesso"
set "common_loading=Carregando..."
set "common_goodbye=Até logo!"
endlocal & exit /b

:lang_RU
set "common_welcome=Dobro pozhalovat"
set "common_exit=Vykhod"
set "common_back=Nazad"
set "common_invalid=Nepravilnyy variant"
set "common_error=Oshibka"
set "common_success=Uspekh"
set "common_loading=Zagruzka..."
set "common_goodbye=Do svidaniya!"
endlocal & exit /b

:lang_JA
set "common_welcome=Youkoso"
set "common_exit=Shuryo"
set "common_back=Modoru"
set "common_invalid=Fukatekina opushon"
set "common_error=Erao"
set "common_success=Seiko"
set "common_loading=Rodin chu..."
set "common_goodbye=Sayounara!"
endlocal & exit /b

:lang_ZH
set "common_welcome=Huanyng"
set "common_exit=Tuichu"
set "common_back=Fanhui"
set "common_invalid=Wufa xuanxiang"
set "common_error=Cuowu"
set "common_success=Chenggung"
set "common_loading=Zai jiaiin zhong..."
set "common_goodbye=Zaijian!"
endlocal & exit /b

:lang_NL
set "common_welcome=Welkom"
set "common_exit=Afsluiten"
set "common_back=Terug"
set "common_invalid=Ongeldige optie"
set "common_error=Fout"
set "common_success=Succes"
set "common_loading=Bezig met laden..."
set "common_goodbye=Tot ziens!"
endlocal & exit /b

:lang_PL
set "common_welcome=Witaj"
set "common_exit=Wyjscie"
set "common_back=Powrot"
set "common_invalid=Nieprawidlowa opcja"
set "common_error=Blad"
set "common_success=Powodzenie"
set "common_loading=Wczytywanie..."
set "common_goodbye=Do widzenia!"
endlocal & exit /b
