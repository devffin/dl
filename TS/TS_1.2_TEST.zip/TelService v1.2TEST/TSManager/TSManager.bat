@echo off
title TelService Manager
setlocal enabledelayedexpansion
cd /d "%~dp0"

if /i not "%~1"=="" goto :argmode

if not exist "..\config\lang.txt" (
    call :detect_os_language
    echo language=!detected_language!>"..\config\lang.txt"
)

call :load_language

:main_menu
    echo !tsm_title!
    echo ==================================================
    echo !tsm_welcome!
    echo 1. !tsm_uninstall!
    echo 2. !tsm_help_option!
    echo.
    echo 0. !tsm_exit!
    echo.
    set /p "main_choice=!tsm_select_option! (0/2) : "
    if "%main_choice%"=="1" (
        start "" "%~f0" uninstall
        exit /b
    )
    if "%main_choice%"=="2" (
        start "" "%~f0" help
        exit /b
    )
    if "%main_choice%"=="0" exit /b
    goto main_menu

:argmode
if /i "%~1"=="uninstall" (
    for %%I in ("%~dp0..") do set "install_dir=%%~fI"
    color 4
    echo !tsm_uninstall_confirm!
    echo ==================================================
    echo !tsm_uninstall_warning!
    echo !tsm_uninstall_irreversible!
    echo.
    set /p "confirm=!tsm_continue_yn!: "
    if /i "!confirm!"=="N" (
        echo !tsm_uninstall_cancelled!
        timeout /t 2 >nul
        exit /b
    )
    if /i not "!confirm!"=="O" (
        if /i not "!confirm!"=="Y" (
            echo !tsm_invalid_response!
            timeout /t 2 >nul
            exit /b 1
        )
    )

    call :requireAdmin uninstall
    if errorlevel 2 exit /b
    if errorlevel 1 (
        echo !tsm_elevation_cancelled!
        timeout /t 2 >nul
        exit /b 1
    )

    start "" "..\unins000.exe"
    exit /b 1
)

if /i "%~1"=="install" (
    echo !tsm_error_install!
    echo !tsm_use_setup!
    echo https://github.com/devffin/TelService/releases
    pause
    exit /b
)

if /i "%~1"=="help" (
    echo !tsm_usage!: TSManager.bat [!tsm_option_label!]
    echo.
    echo !tsm_options!:
    echo   install     - !tsm_install_app! (não suportado por este script^)
    echo   uninstall   - !tsm_uninstall_app!
    echo   help        - !tsm_show_help!
    echo.
    echo !tsm_no_option_menu!
    pause
    exit /b
)

if /i "%~1"=="update" (
    if not exist config\ mkdir config
    if not exist config\updates.txt (
        >config\updates.txt echo 1
    )
    if not exist "config\lang.txt" (
        >config\lang.txt echo language=FR
    )

    call :load_language

    set "updates="
    set /p updates=<config\updates.txt
    if /i "!updates!"=="updates=1" set "updates=1"
    if /i "!updates!"=="updates=0" set "updates=0"
    if "!updates!"=="1 " set "updates=1"
    if "!updates!"=="0 " set "updates=0"
    if "!updates!"=="" set "updates=1"
    if not "!updates!"=="1" if not "!updates!"=="0" set "updates=1"

    if "!updates!"=="0" (
        echo !tsm_updates_disabled!
        pause
        exit /b
    )

    echo !tsm_checking_updates!...
    powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://devffin.github.io/dl/TS/version.txt' -OutFile 'temp_version.txt'" 2>nul
    powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://devffin.github.io/dl/TS/build.txt' -OutFile 'temp_build.txt'" 2>nul

    if not exist "temp_version.txt" goto :net_error
    if not exist "temp_build.txt" goto :net_error
    if not exist "version.txt" (
        echo !tsm_version_not_found!
        goto :cleanup
    )
    if not exist "build.txt" (
        echo !tsm_build_not_found!
        goto :cleanup
    )

    set /p remote_ver=<temp_version.txt
    set /p local_ver=<version.txt
    set /p remote_build=<temp_build.txt
    set /p local_build=<build.txt

    set "update_needed=0"
    if /i not "!local_ver!"=="!remote_ver!" set "update_needed=1"
    if /i not "!local_build!"=="!remote_build!" set "update_needed=1"

    if "!update_needed!"=="0" (
        echo !tsm_up_to_date! ^(v!local_ver! / !local_build!^).
        goto :cleanup
    )

    echo !tsm_update_available!
    echo !tsm_local!: !local_ver! ^(!local_build!^)
    echo !tsm_remote!: !remote_ver! ^(!remote_build!^)
    echo !tsm_downloading!...
    powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://devffin.github.io/dl/TS/TS.zip' -OutFile 'TS.zip'" 2>nul
    if not exist "TS.zip" (
        echo !tsm_download_failed!
        goto :cleanup
    )

    echo !tsm_extracting!...
    >upd.bat echo @echo off
    >>upd.bat echo powershell -NoProfile -Command "Expand-Archive -Path 'TS.zip' -DestinationPath '.' -Force" 2^>nul
    >>upd.bat echo del /q TS.zip 2^>nul
    >>upd.bat echo if exist TelService.exe start "" "TelService.exe"
    >>upd.bat echo if not exist TelService.exe if exist telservice.bat start "" "telservice.bat"
    >>upd.bat echo del /q "%%~f0"
    echo !tsm_update_complete! v!remote_ver! ^(!remote_build!^)
    start "" upd.bat
    goto :cleanup_fast_exit
)

echo Argument invalide: %~1
exit /b 1

:requireAdmin
net session >nul 2>&1
if not errorlevel 1 exit /b 0
powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -ArgumentList '%~1' -Verb RunAs"
if errorlevel 1 exit /b 1
exit /b 2

:net_error
echo !tsm_update_check_failed!

:cleanup
if exist temp_version.txt del /q temp_version.txt
if exist temp_build.txt del /q temp_build.txt
if exist TS.zip del /q TS.zip
pause
exit /b

:cleanup_fast_exit
if exist temp_version.txt del /q temp_version.txt
if exist temp_build.txt del /q temp_build.txt
exit /b

:load_language
setlocal enabledelayedexpansion
set "lang=FR"
if exist "config\lang.txt" (
    for /f "tokens=2 delims==" %%A in ('type config\lang.txt ^| findstr /i "^language"') do (
        set "lang=%%A"
    )
)
set "lang=!lang: =!"

if /i "!lang!"=="EN" goto :lang_EN
if /i "!lang!"=="ES" goto :lang_ES
if /i "!lang!"=="DE" goto :lang_DE
if /i "!lang!"=="IT" goto :lang_IT
if /i "!lang!"=="PT" goto :lang_PT
if /i "!lang!"=="RU" goto :lang_RU
if /i "!lang!"=="JA" goto :lang_JA
if /i "!lang!"=="ZH" goto :lang_ZH
if /i "!lang!"=="NL" goto :lang_NL
if /i "!lang!"=="PL" goto :lang_PL
goto :lang_FR

:lang_EN
set "tsm_title=TSManager - TelService Manager"
set "tsm_welcome=Welcome to TelService Manager."
set "tsm_uninstall=Uninstall TelService"
set "tsm_help_option=Help with this program arguments"
set "tsm_exit=Exit Manager"
set "tsm_select_option=Select an option"
set "tsm_uninstall_confirm=Confirmation of uninstallation of TelService"
set "tsm_uninstall_warning=You are about to uninstall TelService from your system."
set "tsm_uninstall_irreversible=This action is irreversible and will remove TelService files."
set "tsm_continue_yn=Do you want to continue? (Y/N)"
set "tsm_uninstall_cancelled=Uninstallation canceled."
set "tsm_invalid_response=Invalid response."
set "tsm_elevation_cancelled=Elevation canceled. Operation interrupted."
set "tsm_error_install=ERROR: This script is only intended for TelService management."
set "tsm_use_setup=To install TelService, please run the installation setup."
set "tsm_install_app=Install TelService"
set "tsm_uninstall_app=Uninstall TelService"
set "tsm_show_help=Show this help message"
set "tsm_usage=Usage"
set "tsm_option_label=option"
set "tsm_options=Options"
set "tsm_no_option_menu=If no option is provided, the main menu opens."
set "tsm_updates_disabled=Updates disabled."
set "tsm_checking_updates=Checking for updates to TelService"
set "tsm_version_not_found=version.txt not found."
set "tsm_build_not_found=build.txt not found."
set "tsm_up_to_date=TelService is up to date"
set "tsm_local=Local"
set "tsm_remote=Remote"
set "tsm_update_available=Update available."
set "tsm_downloading=Downloading files"
set "tsm_download_failed=Failed to download the update."
set "tsm_extracting=Extracting TS.zip"
set "tsm_update_complete=Update completed. New version:"
set "tsm_update_check_failed=Unable to check for updates. Check your internet connection."
exit /b

:lang_ES
set "tsm_title=TSManager - Gestor de TelService"
set "tsm_welcome=Bienvenido al gestor de TelService."
set "tsm_uninstall=Desinstalar TelService"
set "tsm_help_option=Ayuda con los argumentos de este programa"
set "tsm_exit=Salir del gestor"
set "tsm_select_option=Seleccione una opcion"
set "tsm_uninstall_confirm=Confirmacion de desinstalacion de TelService"
set "tsm_uninstall_warning=Usted esta a punto de desinstalar TelService de su sistema."
set "tsm_uninstall_irreversible=Esta accion es irreversible y eliminara los archivos de TelService."
set "tsm_continue_yn=Desea continuar? (S/N)"
set "tsm_uninstall_cancelled=Desinstalacion cancelada."
set "tsm_invalid_response=Respuesta invalida."
set "tsm_elevation_cancelled=Elevacion cancelada. Operacion interrumpida."
set "tsm_error_install=ERROR: Este script esta destinado solo para la gestion de TelService."
set "tsm_use_setup=Para instalar TelService, ejecute el asistente de instalacion."
set "tsm_install_app=Instalar TelService"
set "tsm_uninstall_app=Desinstalar TelService"
set "tsm_show_help=Mostrar este mensaje de ayuda"
set "tsm_usage=Uso"
set "tsm_option_label=opcion"
set "tsm_options=Opciones"
set "tsm_no_option_menu=Si no se proporciona ninguna opcion, se abre el menu principal."
set "tsm_updates_disabled=Actualizaciones deshabilitadas."
set "tsm_checking_updates=Comprobando actualizaciones para TelService"
set "tsm_version_not_found=version.txt no encontrado."
set "tsm_build_not_found=build.txt no encontrado."
set "tsm_up_to_date=TelService esta actualizado"
set "tsm_local=Local"
set "tsm_remote=Remoto"
set "tsm_update_available=Actualizacion disponible."
set "tsm_downloading=Descargando archivos"
set "tsm_download_failed=Fallo al descargar la actualizacion."
set "tsm_extracting=Extrayendo TS.zip"
set "tsm_update_complete=Actualizacion completada. Nueva version:"
set "tsm_update_check_failed=No se puede verificar las actualizaciones. Verifique su conexion a Internet."
exit /b

:lang_DE
set "tsm_title=TSManager - TelService-Manager"
set "tsm_welcome=Willkommen zum TelService-Manager."
set "tsm_uninstall=TelService deinstallieren"
set "tsm_help_option=Hilfe mit den Argumenten dieses Programms"
set "tsm_exit=Manager beenden"
set "tsm_select_option=Wahlen Sie eine Option"
set "tsm_uninstall_confirm=Bestatigung der Deinstallation von TelService"
set "tsm_uninstall_warning=Sie sind dabei, TelService von Ihrem System zu deinstallieren."
set "tsm_uninstall_irreversible=Diese Aktion ist nicht ruckgangig zu machen und entfernt TelService-Dateien."
set "tsm_continue_yn=Mochten Sie fortfahren? (J/N)"
set "tsm_uninstall_cancelled=Deinstallation abgebrochen."
set "tsm_invalid_response=Ungultige Antwort."
set "tsm_elevation_cancelled=Erhohung abgebrochen. Operation unterbrochen."
set "tsm_error_install=FEHLER: Dieses Skript ist nur fur die TelService-Verwaltung bestimmt."
set "tsm_use_setup=Zum Installieren von TelService fuhren Sie das Installationsprogramm aus."
set "tsm_install_app=TelService installieren"
set "tsm_uninstall_app=TelService deinstallieren"
set "tsm_show_help=Diese Hilfemeldung anzeigen"
set "tsm_usage=Verwendung"
set "tsm_option_label=option"
set "tsm_options=Optionen"
set "tsm_no_option_menu=Wenn keine Option angegeben wird, wird das Hauptmenue geoffnet."
set "tsm_updates_disabled=Updates deaktiviert."
set "tsm_checking_updates=Suche nach Updates fur TelService"
set "tsm_version_not_found=version.txt nicht gefunden."
set "tsm_build_not_found=build.txt nicht gefunden."
set "tsm_up_to_date=TelService ist auf dem neuesten Stand"
set "tsm_local=Lokal"
set "tsm_remote=Fernbedienung"
set "tsm_update_available=Update verfugbar."
set "tsm_downloading=Dateien herunterladen"
set "tsm_download_failed=Fehler beim Herunterladen des Updates."
set "tsm_extracting=Extrahieren von TS.zip"
set "tsm_update_complete=Update abgeschlossen. Neue Version:"
set "tsm_update_check_failed=Updates konnen nicht uberpruft werden. Uberprufen Sie Ihre Internetverbindung."
exit /b

:lang_IT
set "tsm_title=TSManager - Gestore TelService"
set "tsm_welcome=Benvenuto in Gestione TelService."
set "tsm_uninstall=Disinstalla TelService"
set "tsm_help_option=Aiuto con gli argomenti di questo programma"
set "tsm_exit=Esci da Gestione"
set "tsm_select_option=Seleziona un'opzione"
set "tsm_uninstall_confirm=Conferma disinstallazione TelService"
set "tsm_uninstall_warning=Stai per disinstallare TelService dal tuo sistema."
set "tsm_uninstall_irreversible=Questa azione e irreversibile e rimuovera i file TelService."
set "tsm_continue_yn=Vuoi continuare? (S/N)"
set "tsm_uninstall_cancelled=Disinstallazione annullata."
set "tsm_invalid_response=Risposta non valida."
set "tsm_elevation_cancelled=Elevazione annullata. Operazione interrotta."
set "tsm_error_install=ERRORE: Questo script e solo per la gestione di TelService."
set "tsm_use_setup=Per installare TelService, esegui il programma di installazione."
set "tsm_install_app=Installa TelService"
set "tsm_uninstall_app=Disinstalla TelService"
set "tsm_show_help=Mostra questo messaggio di aiuto"
set "tsm_usage=Utilizzo"
set "tsm_option_label=opzione"
set "tsm_options=Opzioni"
set "tsm_no_option_menu=Se nessuna opzione e fornita, si apre il menu principale."
set "tsm_updates_disabled=Aggiornamenti disabilitati."
set "tsm_checking_updates=Controllo aggiornamenti per TelService"
set "tsm_version_not_found=version.txt non trovato."
set "tsm_build_not_found=build.txt non trovato."
set "tsm_up_to_date=TelService e aggiornato"
set "tsm_local=Locale"
set "tsm_remote=Remoto"
set "tsm_update_available=Aggiornamento disponibile."
set "tsm_downloading=Download file"
set "tsm_download_failed=Impossibile scaricare l'aggiornamento."
set "tsm_extracting=Estrazione TS.zip"
set "tsm_update_complete=Aggiornamento completato. Nuova versione:"
set "tsm_update_check_failed=Impossibile controllare gli aggiornamenti. Controllare la connessione Internet."
exit /b

:lang_PT
set "tsm_title=TSManager - Gerenciador TelService"
set "tsm_welcome=Bem-vindo ao Gerenciador TelService."
set "tsm_uninstall=Desinstalar TelService"
set "tsm_help_option=Ajuda com os argumentos deste programa"
set "tsm_exit=Sair do Gerenciador"
set "tsm_select_option=Selecione uma opcao"
set "tsm_uninstall_confirm=Confirmacao de desinstalacao de TelService"
set "tsm_uninstall_warning=Voce esta prestes a desinstalar TelService do seu sistema."
set "tsm_uninstall_irreversible=Esta acao e irreversivel e removera os arquivos TelService."
set "tsm_continue_yn=Deseja continuar? (S/N)"
set "tsm_uninstall_cancelled=Desinstalacao cancelada."
set "tsm_invalid_response=Resposta invalida."
set "tsm_elevation_cancelled=Elevacao cancelada. Operacao interrompida."
set "tsm_error_install=ERRO: Este script e apenas para gerenciamento TelService."
set "tsm_use_setup=Para instalar TelService, execute o programa de instalacao."
set "tsm_install_app=Instalar TelService"
set "tsm_uninstall_app=Desinstalar TelService"
set "tsm_show_help=Mostrar esta mensagem de ajuda"
set "tsm_usage=Uso"
set "tsm_option_label=opcao"
set "tsm_options=Opcoes"
set "tsm_no_option_menu=Se nenhuma opcao for fornecida, o menu principal sera aberto."
set "tsm_updates_disabled=Atualizacoes desabilitadas."
set "tsm_checking_updates=Verificando atualizacoes para TelService"
set "tsm_version_not_found=version.txt nao encontrado."
set "tsm_build_not_found=build.txt nao encontrado."
set "tsm_up_to_date=TelService esta atualizado"
set "tsm_local=Local"
set "tsm_remote=Remoto"
set "tsm_update_available=Atualizacao disponivel."
set "tsm_downloading=Baixando arquivos"
set "tsm_download_failed=Falha ao baixar a atualizacao."
set "tsm_extracting=Extraindo TS.zip"
set "tsm_update_complete=Atualizacao concluida. Nova versao:"
set "tsm_update_check_failed=Nao e possivel verificar atualizacoes. Verifique sua conexao com Internet."
exit /b

:lang_RU
set "tsm_title=TSManager - Menedzher TelService"
set "tsm_welcome=Dobro pozhalovat v Menedzher TelService."
set "tsm_uninstall=Odinstalyavirovat TelService"
set "tsm_help_option=Pomosh po argumentam etoy programmy"
set "tsm_exit=Vykhod iz Menedzheera"
set "tsm_select_option=Vyberite variant"
set "tsm_uninstall_confirm=Podtverzhdenie odinstalyacii TelService"
set "tsm_uninstall_warning=Vy sobirayetes odinstalyavirovat TelService iz vashey sistemy."
set "tsm_uninstall_irreversible=Eto deystvie ne mozhet byt otmeneno i udalit fayly TelService."
set "tsm_continue_yn=Vy khotite prodolzhit? (D/N)"
set "tsm_uninstall_cancelled=Odinstalyaciya otmenena."
set "tsm_invalid_response=Nepravilnyy otvet."
set "tsm_elevation_cancelled=Povysheniye otmeneno. Operaciya prerrana."
set "tsm_error_install=OSHIBKA: Etot skript tolko dlya upravleniya TelService."
set "tsm_use_setup=Dlya installyacii TelService zapustite programmu ustanovki."
set "tsm_install_app=Installyavirovat TelService"
set "tsm_uninstall_app=Odinstalyavirovat TelService"
set "tsm_show_help=Pokazat etu spravku"
set "tsm_usage=Ispolzovanie"
set "tsm_option_label=variant"
set "tsm_options=Varianty"
set "tsm_no_option_menu=Esli ne ukzana nikakaya opciya, otkroetsya glavnoe menyu."
set "tsm_updates_disabled=Obnovleniya otklyucheny."
set "tsm_checking_updates=Proverka obnovleniy dlya TelService"
set "tsm_version_not_found=version.txt ne nayden."
set "tsm_build_not_found=build.txt ne nayden."
set "tsm_up_to_date=TelService obnovlen"
set "tsm_local=Lokal"
set "tsm_remote=Udalenno"
set "tsm_update_available=Obnovleniye dostupno."
set "tsm_downloading=Zagruzka faylov"
set "tsm_download_failed=Oshibka pri zagruzke obnovleniya."
set "tsm_extracting=Izvlechenie TS.zip"
set "tsm_update_complete=Obnovleniye zaversheno. Novaya versiya:"
set "tsm_update_check_failed=Nevozmozhno proverit obnovleniya. Proverite vashe podklyuchenie k Internetu."
exit /b

:lang_JA
set "tsm_title=TSManager - TelService Kanrisha"
set "tsm_welcome=TelService Manager e youkoso."
set "tsm_uninstall=TelService wo Akinsutoru suru"
set "tsm_help_option=Kono programa no aryumento no tetsudai"
set "tsm_exit=Manager kara Shutsuryoku"
set "tsm_select_option=Opushon wo sentaku shite kudasai"
set "tsm_uninstall_confirm=TelService Akinsutoru kakunin"
set "tsm_uninstall_warning=Anata wa anata no sisutemu kara TelService wo akinsutoru shiyou toshite imasu."
set "tsm_uninstall_irreversible=Kono aksyon wa modose zu, TelService fairu wo sakujo shimasu."
set "tsm_continue_yn=Zoku shimasu ka? (Y/N)"
set "tsm_uninstall_cancelled=Akinsutoru kyanseru saremashita."
set "tsm_invalid_response=Fukatekina kaito."
set "tsm_elevation_cancelled=Koshin kyanseru saremashita. Opereshyon chushi."
set "tsm_error_install=ERAO: Kono sukuriputo wa TelService kanri nomin desu."
set "tsm_use_setup=TelService o insutoro suru ni wa, insutoro programa o jikkou shite kudasai."
set "tsm_install_app=TelService o Insutoro suru"
set "tsm_uninstall_app=TelService wo Akinsutoru suru"
set "tsm_show_help=Kono herepu messeji o hyoji suru"
set "tsm_usage=Shiyo"
set "tsm_option_label=opushon"
set "tsm_options=Opushon"
set "tsm_no_option_menu=Opushon ga ataenai baai, meinu ga hirakaremasu."
set "tsm_updates_disabled=Koushin ga mukou ni sarete imasu."
set "tsm_checking_updates=TelService no koushin o kakunin shite imasu"
set "tsm_version_not_found=version.txt ga mitsukarimasen."
set "tsm_build_not_found=build.txt ga mitsukarimasen."
set "tsm_up_to_date=TelService wa koshin sarete imasu"
set "tsm_local=Rokuaru"
set "tsm_remote=Rimoto"
set "tsm_update_available=Koushin ga riyou dekilmasu."
set "tsm_downloading=Fairu o daunrodo shite imasu"
set "tsm_download_failed=Koushin no daunrodo ni shippai shimashita."
set "tsm_extracting=TS.zip o chushutsushite imasu"
set "tsm_update_complete=Koushin wa kanryo shimashita. Shin ban:"
set "tsm_update_check_failed=Koushin o kakunin dekimasen. Internet接続を確認してください."
exit /b

:lang_ZH
set "tsm_title=TSManager - TelService Guanliqi"
set "tsm_welcome=Huanyng lai TelService Guanliqi."
set "tsm_uninstall=Xiehzai TelService"
set "tsm_help_option=Yong yu ci chnengxu canysh de bangzhu"
set "tsm_exit=Tuichu Guanliqi"
set "tsm_select_option=
Xuanze yige xuanxiang"
set "tsm_uninstall_confirm=TelService Xiehzai Queding"
set "tsm_uninstall_warning=Ni jang yao cong ni de xitong zhong xiehzai TelService."
set "tsm_uninstall_irreversible=Ciwu dongzuo bu ke chexiao, jiang shan chu TelService fajian."
set "tsm_continue_yn=Ni yao jiaxu ma? (S/N)"
set "tsm_uninstall_cancelled=Xiehzai yichexiao."
set "tsm_invalid_response=Wufa de huiing."
set "tsm_elevation_cancelled=Tisheng yichexiao. Caozuo zhongduan."
set "tsm_error_install=CUOWU: Ci jibenben jingzhi yong yu TelService guanli."
set "tsm_use_setup=Yao anzhung TelService, qing yunxing anzhuang chnengxu."
set "tsm_install_app=Anzhung TelService"
set "tsm_uninstall_app=Xiehzai TelService"
set "tsm_show_help=Xiehshi ci bangzhu xieshon"
set "tsm_usage=Shiyon"
set "tsm_option_label=xuanxiang"
set "tsm_options=Xuanxiang"
set "tsm_no_option_menu=Ruguo mei you gongying xuanxiang, zhu菜单 jang hui daskai."
set "tsm_updates_disabled=Gengxin ye beiingyong."
set "tsm_checking_updates=Jiancha TelService de gengxin"
set "tsm_version_not_found=version.txt  zhang sile."
set "tsm_build_not_found=build.txt zhang sile."
set "tsm_up_to_date=TelService yijing gengxin"
set "tsm_local=Benzhe"
set "tsm_remote=Yuancheng"
set "tsm_update_available=Gengxin ke yong."
set "tsm_downloading=Zai xiehzai fajian"
set "tsm_download_failed=Xiehzai gengxin shubai."
set "tsm_extracting=Zai jieya TS.zip"
set "tsm_update_complete=Gengxin wancheng. Xinban ben:"
set "tsm_update_check_failed=Wufa jiancha gengxin. Qing jiancha Huliangwang lianjie."
exit /b

:lang_NL
set "tsm_title=TSManager - TelService Manager"
set "tsm_welcome=Welkom in TelService Manager."
set "tsm_uninstall=TelService verwijderen"
set "tsm_help_option=Hulp met argumenten van dit programm"
set "tsm_exit=Manager sluiten"
set "tsm_select_option=Selecteer een optie"
set "tsm_uninstall_confirm=Bevestiging verwijdering TelService"
set "tsm_uninstall_warning=Je staat op het punt TelService van je systeem te verwijderen."
set "tsm_uninstall_irreversible=Deze actie kan niet worden ongedaan gemaakt en verwijdert TelService-bestanden."
set "tsm_continue_yn=Wil je doorgaan? (J/N)"
set "tsm_uninstall_cancelled=Verwijdering geannuleerd."
set "tsm_invalid_response=Ongeldig antwoord."
set "tsm_elevation_cancelled=Verhoging geannuleerd. Bewerking onderbroken."
set "tsm_error_install=FOUT: Dit script is alleen voor TelService-beheer."
set "tsm_use_setup=Voer het installatieprogramm uit om TelService te installeren."
set "tsm_install_app=TelService installeren"
set "tsm_uninstall_app=TelService verwijderen"
set "tsm_show_help=Dit helpbericht weergeven"
set "tsm_usage=Gebruik"
set "tsm_option_label=optie"
set "tsm_options=Opties"
set "tsm_no_option_menu=Als geen optie wordt opgegeven, wordt het hoofdmenu geopend."
set "tsm_updates_disabled=Updates uitgeschakeld."
set "tsm_checking_updates=Controleren op updates voor TelService"
set "tsm_version_not_found=version.txt niet gevonden."
set "tsm_build_not_found=build.txt niet gevonden."
set "tsm_up_to_date=TelService is bijgewerkt"
set "tsm_local=Lokaal"
set "tsm_remote=Extern"
set "tsm_update_available=Update beschikbaar."
set "tsm_downloading=Bestanden worden gedownload"
set "tsm_download_failed=Update downloaden mislukt."
set "tsm_extracting=TS.zip wordt uitgepakt"
set "tsm_update_complete=Update voltooid. Nieuwe versie:"
set "tsm_update_check_failed=Kan niet controleren op updates. Controleer je internetverbinding."
exit /b

:lang_PL
set "tsm_title=TSManager - Menadzer TelService"
set "tsm_welcome=Witaj w Menadzierate TelService."
set "tsm_uninstall=Odinstalowac TelService"
set "tsm_help_option=Pomoc z argumentami tego programu"
set "tsm_exit=Wyjscie ze Menadziera"
set "tsm_select_option=Wybierz opcje"
set "tsm_uninstall_confirm=Potwierdzenie odinstalowania TelService"
set "tsm_uninstall_warning=Zamierzasz odinstalowac TelService z twojego systemu."
set "tsm_uninstall_irreversible=Ta akcja jest nieodwracalna i usunie pliki TelService."
set "tsm_continue_yn=Czy chcesz kontynuowac? (T/N)"
set "tsm_uninstall_cancelled=Odinstalowanie anulowano."
set "tsm_invalid_response=N iewalidna odpowiedz."
set "tsm_elevation_cancelled=Podniesienie anulowano. Operacja przerwana."
set "tsm_error_install=BLAD: Ten skrypt jest tylko do zarządzania TelService."
set "tsm_use_setup=Aby zainstalowac TelService, uruchom program instalatora."
set "tsm_install_app=Zainstalowac TelService"
set "tsm_uninstall_app=Odinstalowac TelService"
set "tsm_show_help=Pokaz te wiadomosc pomocy"
set "tsm_usage=Uzycie"
set "tsm_option_label=opcja"
set "tsm_options=Opcje"
set "tsm_no_option_menu=Jesli nie podano zadnej opcji, otworzy sie menu glowne."
set "tsm_updates_disabled=Aktualizacje wylaczone."
set "tsm_checking_updates=Sprawdzam aktualizacje TelService"
set "tsm_version_not_found=version.txt nie znaleziony."
set "tsm_build_not_found=build.txt nie znaleziony."
set "tsm_up_to_date=TelService jest zaktualizowany"
set "tsm_local=Lokalny"
set "tsm_remote=Zdalny"
set "tsm_update_available=Aktualizacja dostepna."
set "tsm_downloading=Pobieranie plikow"
set "tsm_download_failed=Blad pobierania aktualizacji."
set "tsm_extracting=Ekstrakcja TS.zip"
set "tsm_update_complete=Aktualizacja zakonczona. Nowa wersja:"
set "tsm_update_check_failed=Nie mozna sprawdzic aktualizacji. Sprawdz swoje polaczenie internetowe."
exit /b
set "tsm_title=TSManager - Gestionnaire de TelService"
set "tsm_welcome=Bienvenue dans le gestionnaire de TelService."
set "tsm_uninstall=Desinstaller TelService"
set "tsm_help_option=Aide avec les arguments de ce programme"
set "tsm_exit=Quitter le gestionnaire"
set "tsm_select_option=Selectionnez une option"
set "tsm_uninstall_confirm=Confirmation de desinstallation de TelService"
set "tsm_uninstall_warning=Vous etes sur le point de desinstaller TelService de votre systeme."
set "tsm_uninstall_irreversible=Cette action est irreversible et supprimera les fichiers de TelService."
set "tsm_continue_yn=Voulez-vous continuer ? (O/N)"
set "tsm_uninstall_cancelled=Desinstallation annulee."
set "tsm_invalid_response=Reponse invalide."
set "tsm_elevation_cancelled=Elevation annulee. Operation interrompue."
set "tsm_error_install=ERREUR : Ce script est uniquement destine a la gestion de TelService."
set "tsm_use_setup=Pour installer TelService, veuillez executer le setup d'installation."
set "tsm_install_app=Installer TelService"
set "tsm_uninstall_app=Desinstaller TelService"
set "tsm_show_help=Afficher ce message d'aide"
set "tsm_usage=Usage"
set "tsm_option_label=option"
set "tsm_options=Options"
set "tsm_no_option_menu=Si aucune option n'est fournie, le menu principal s'ouvre."
set "tsm_updates_disabled=Mises a jour desactivees."
set "tsm_checking_updates=Verification des mises a jour pour TelService"
set "tsm_version_not_found=version.txt introuvable."
set "tsm_build_not_found=build.txt introuvable."
set "tsm_up_to_date=TelService est a jour"
set "tsm_local=Local"
set "tsm_remote=Distant"
set "tsm_update_available=Mise a jour disponible."
set "tsm_downloading=Telechargement des fichiers"
set "tsm_download_failed=Echec du telechargement de la mise a jour."
set "tsm_extracting=Extraction de TS.zip"
set "tsm_update_complete=Mise a jour terminee. Nouvelle version:"
set "tsm_update_check_failed=Impossible de verifier les mises a jour. Verifiez votre connexion internet."
exit /b

:detect_os_language
set "detected_language=FR"
for /f "tokens=2 delims==" %%A in ('wmic os get locale ^| findstr .'') do (
    set "os_locale=%%A"
)
set "os_locale=!os_locale: =!"

if "!os_locale!"=="40C" set "detected_language=FR"
if "!os_locale!"=="C0C" set "detected_language=FR"
if "!os_locale!"=="80C" set "detected_language=FR"
if "!os_locale!"=="100C" set "detected_language=FR"
if "!os_locale!"=="140C" set "detected_language=FR"
if "!os_locale!"=="180C" set "detected_language=FR"
if "!os_locale!"=="1C0C" set "detected_language=FR"

if "!os_locale!"=="409" set "detected_language=EN"
if "!os_locale!"=="809" set "detected_language=EN"
if "!os_locale!"=="C09" set "detected_language=EN"
if "!os_locale!"=="1009" set "detected_language=EN"
if "!os_locale!"=="1409" set "detected_language=EN"
if "!os_locale!"=="1809" set "detected_language=EN"
if "!os_locale!"=="1C09" set "detected_language=EN"
if "!os_locale!"=="2009" set "detected_language=EN"
if "!os_locale!"=="2409" set "detected_language=EN"
if "!os_locale!"=="2809" set "detected_language=EN"
if "!os_locale!"=="2C09" set "detected_language=EN"
if "!os_locale!"=="3009" set "detected_language=EN"
if "!os_locale!"=="3409" set "detected_language=EN"

if "!os_locale!"=="C0A" set "detected_language=ES"
if "!os_locale!"=="40A" set "detected_language=ES"
if "!os_locale!"=="80A" set "detected_language=ES"
if "!os_locale!"=="100A" set "detected_language=ES"
if "!os_locale!"=="140A" set "detected_language=ES"
if "!os_locale!"=="180A" set "detected_language=ES"
if "!os_locale!"=="1C0A" set "detected_language=ES"
if "!os_locale!"=="200A" set "detected_language=ES"

if "!os_locale!"=="407" set "detected_language=DE"
if "!os_locale!"=="807" set "detected_language=DE"
if "!os_locale!"=="C07" set "detected_language=DE"
if "!os_locale!"=="1007" set "detected_language=DE"
if "!os_locale!"=="1407" set "detected_language=DE"

if "!os_locale!"=="410" set "detected_language=IT"
if "!os_locale!"=="810" set "detected_language=IT"

if "!os_locale!"=="416" set "detected_language=PT"
if "!os_locale!"=="816" set "detected_language=PT"

if "!os_locale!"=="419" set "detected_language=RU"
if "!os_locale!"=="819" set "detected_language=RU"

if "!os_locale!"=="411" set "detected_language=JA"

if "!os_locale!"=="404" set "detected_language=ZH"
if "!os_locale!"=="804" set "detected_language=ZH"
if "!os_locale!"=="C04" set "detected_language=ZH"

if "!os_locale!"=="413" set "detected_language=NL"
if "!os_locale!"=="813" set "detected_language=NL"

if "!os_locale!"=="415" set "detected_language=PL"

exit /b
