@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

if not exist config\ mkdir config

if exist config\updates.txt (
    set /p updates=<config\updates.txt
) else (
    echo 1>config\updates.txt
    set updates=1
)
if /i "%updates%"=="updates=1" set updates=1
if /i "%updates%"=="updates=0" set updates=0
if "%updates%"=="1 " set updates=1
if "%updates%"=="0 " set updates=0
if not "%updates%"=="1" if not "%updates%"=="0" set updates=1

if exist config\color.txt (
    set /p color=<config\color.txt
) else (
    echo 07>config\color.txt
    set color=07
)
set "color=%color: =%"
if "%color%"=="" set color=07
if "%color:~1,1%"=="" set color=0%color%
echo.%color%| findstr /r /i "^[0-9A-F][0-9A-F]$" >nul || set color=07
if /i "%color:~0,1%"=="%color:~1,1%" set color=07

if "%updates%"=="1" set update_status=Activees
if "%updates%"=="0" set update_status=Desactivees

set background=%color:~0,1%
set text=%color:~1,1%

:settings
cls
echo ==================================================
echo              Parametres de TelService
echo ==================================================
echo.
echo 1. Mises a jour : %update_status%
echo 2. Themes et personnalisation
echo 3. Desinstaller TelService
echo 4. A propos de TelService
echo 5. Reinitialiser les parametres
echo 6. Applications
echo.
echo 0. Retour au menu principal
echo.
set /p choice="Selectionnez une option (0/5): "

if "%choice%"=="1" (
    if "%updates%"=="1" (
        >config\updates.txt echo 0
        set updates=0
        set update_status=Desactivees
    ) else (
        >config\updates.txt echo 1
        set updates=1
        set update_status=Activees
    )
    echo Mises a jour !update_status!.
    pause
    goto settings
)
if "%choice%"=="2" (
    cls
    echo Themes et personnalisation
    echo ==================================================
    echo.
    set /P background="Couleur de fond (0-F, actuellement %background%): "
    set /p text="Couleur du texte (0-F, actuellement %text%): "
    set "background=!background:~0,1!"
    set "text=!text:~0,1!"
    echo.!background!| findstr /r /i "^[0-9A-F]$" >nul || set "background=0"
    echo.!text!| findstr /r /i "^[0-9A-F]$" >nul || set "text=7"
    if /i "!background!"=="!text!" (
        if /i "!background!"=="7" (
            set "text=0"
        ) else (
            set "text=7"
        )
    )
    set "newcolor=!background!!text!"
    if "!newcolor!"=="" set "newcolor=07"
    >config\color.txt echo !newcolor!
    color !newcolor! >nul 2>nul
    echo Couleurs mises a jour. Veuillez redemarrer le programme pour appliquer les changements.
    pause
    goto settings
)
if "%choice%"=="3" (
    start "" "TSManager\TSManager.bat" uninstall
    exit /b
)
if "%choice%"=="4" (
    cls
    echo A propos de TelService
    echo ==================================================
    echo.
    set "ver=Inconnue"
    set "bld=Inconnu"
    if exist version.txt set /p ver=<version.txt
    if exist build.txt set /p bld=<build.txt
    echo TelService !ver! !bld! - ^(c^) 2026 devffin
    echo Utilise l'API d'Open-Meteo pour les previsions meteo.
    echo Utilise ascii.live pour l'application ASCIImation.
    echo.
    echo Ce logiciel est en cours de developpement et peut contenir des bugs.
    echo N'hesitez pas a faire part de vos retours et suggestions sur le GitHub du projet.
    echo https://github.com/devffin/TelService
    echo.
    echo Si vous souhaitez avoir une version plus ancienne, vous pouvez me contacter par mail.
    echo contact.diffin@gmail.com ou comptevideo.lse@outlook.com ^(LSE Studios^)
    echo ==================================================
    pause
    goto settings
)
if "%choice%"=="5" (
    >config\updates.txt echo 1
    >config\color.txt echo 07
    set updates=1
    set update_status=Activees
    set color=07
    set background=0
    set text=7
    echo Parametres reinitialises.
    pause
    goto settings
)
if "%choice%"=="6" (
    cls
    echo Applications installees
    echo ==================================================
    echo.
    echo X TSCore   X TSMenu    X TSManager TSMode
    echo X Settings O ASCIImation   O freeVM    O Jeux
    echo O Meteo    O Musique   O myAIRBENZ X TelStore
    echo X GetMeteo X IIS   O TSCode    O .TSC DeScript
    echo X Config Loader    X VerMgr
    echo ==================================================
    pause
    goto settings
)
if "%choice%"=="0" (
    exit /b
)
echo Option invalide. Veuillez reessayer.
pause
goto settings
