@echo off
title LSE FreeVM
setlocal enabledelayedexpansion
cd /d "%~dp0"
chcp 65001 >nul

REM Create parent config if needed
if not exist "..\config\lang.txt" (
    if not exist "..\config" mkdir "..\config"
    call :detect_os_language
    echo language=!detected_language!>"..\config\lang.txt"
)

REM Load language
call :load_language

:menu
cls
echo ============================================
echo                 !vm_title!
echo                 !vm_subtitle!
echo ============================================
echo.
echo 1. !vm_option_1!
echo 2. !vm_option_2!
echo 3. !vm_option_3!
echo 0. !vm_option_0!
echo.
set /p choice="!vm_choose!: "

if "%choice%"=="1" goto list_vms
if "%choice%"=="2" goto rent_vm
if "%choice%"=="3" goto my_rentals
if "%choice%"=="0" goto end
echo !vm_invalid!
pause
goto menu

:list_vms
cls
echo !vm_list_title!
echo.
echo 1. !vm_1!
echo 2. !vm_2!
echo 3. !vm_3!
echo 4. !vm_4!
echo 5. !vm_5!
echo.
echo !vm_legal!
pause
goto menu

:rent_vm
cls
echo !vm_rent_msg!
start "" "https://forms.gle/7kd8NjzYbafvQRyM9"
pause
goto menu

:my_rentals
cls
echo !vm_rentals_title!
echo.
set /p choice="!vm_enter_username!: "
set "user_id=%choice: =%"
set "user_id=%user_id:"=%"
if "%user_id%"=="" (
    echo !vm_empty_username!
    pause
    goto menu
)
echo !vm_retrieving_rentals! %user_id%...
echo.
set "loc_file=%temp%\locs_%random%_%random%.txt"
set "USER_ID_RAW=%user_id%"
powershell -NoProfile -Command "$u=[uri]::EscapeDataString($env:USER_ID_RAW); $url='https://devffin.github.io/dl/locs/' + $u + '.txt'; try { $null = Invoke-WebRequest -Uri $url -OutFile $env:loc_file -ErrorAction Stop; exit 0 } catch { exit 1 }" >nul 2>nul
if errorlevel 1 (
    echo !vm_no_rental! %user_id% !vm_or_unavailable!
) else (
    type "%loc_file%" 2>nul
)
del "%loc_file%" 2>nul
echo.
pause
goto menu

:end
echo !vm_goodbye!
timeout /t 2 >nul

:load_language
set "lang=FR"
if exist "..\config\lang.txt" (
    for /f "tokens=2 delims==" %%A in ('type ..\config\lang.txt ^| findstr /i "^language"') do (
        set "lang=%%A"
    )
)
set "lang=!lang: =!"

if /i "!lang!"=="EN" goto :lang_EN
if /i "!lang!"=="ES" goto :lang_ES
if /i "!lang!"=="DE" goto :lang_DE
if /i "!lang!"=="IT" goto :lang_IT
if /i "!lang!"=="PT" goto :lang_PT
if /i "!lang!"=="RU" goto :lang_RU
if /i "!lang!"=="JA" goto :lang_JA
if /i "!lang!"=="ZH" goto :lang_ZH
if /i "!lang!"=="NL" goto :lang_NL
if /i "!lang!"=="PL" goto :lang_PL
goto :lang_FR

:lang_EN
set "vm_title=LSE FreeVM"
set "vm_subtitle=Free and Legal VM Rentals"
set "vm_option_1=View Available VMs"
set "vm_option_2=Rent a VM"
set "vm_option_3=My Active Rentals"
set "vm_option_0=Quit"
set "vm_choose=Choose an option"
set "vm_invalid=Invalid option."
set "vm_list_title=Available VMs"
set "vm_1=Ubuntu 24.04 LTS Desktop/Server - For web development"
set "vm_2=Windows 10/11 - For Windows applications"
set "vm_3=Zorin OS 18 - For beginner Linux users"
set "vm_4=Fedora 43 - For developers and testers"
set "vm_5=Coming soon ..."
set "vm_legal=All VMs are free and legal."
set "vm_rent_msg=Opening rental form..."
set "vm_rentals_title=Your Active Rentals"
set "vm_enter_username=Enter your username"
set "vm_empty_username=Empty username."
set "vm_retrieving_rentals=Retrieving rentals for"
set "vm_no_rental=No rental found for"
set "vm_or_unavailable=or service unavailable."
set "vm_goodbye=Thank you for using LSE FreeVM."
exit /b

:lang_ES
set "vm_title=LSE FreeVM"
set "vm_subtitle=Alquiler de VMs Gratis y Legales"
set "vm_option_1=Ver VMs Disponibles"
set "vm_option_2=Alquilar una VM"
set "vm_option_3=Mis Alquileres Activos"
set "vm_option_0=Salir"
set "vm_choose=Elige una opcion"
set "vm_invalid=Opcion invalida."
set "vm_list_title=VMs Disponibles"
set "vm_1=Ubuntu 24.04 LTS Desktop/Server - Para desarrollo web"
set "vm_2=Windows 10/11 - Para aplicaciones Windows"
set "vm_3=Zorin OS 18 - Para usuarios Linux principiantes"
set "vm_4=Fedora 43 - Para desarrolladores y probadores"
set "vm_5=Proximamente ..."
set "vm_legal=Todas las VMs son gratuitas y legales."
set "vm_rent_msg=Abriendo formulario de alquiler..."
set "vm_rentals_title=Tus Alquileres Activos"
set "vm_enter_username=Ingresa tu nombre de usuario"
set "vm_empty_username=Nombre de usuario vacio."
set "vm_retrieving_rentals=Recuperando alquileres para"
set "vm_no_rental=Ningun alquiler encontrado para"
set "vm_or_unavailable=o servicio no disponible."
set "vm_goodbye=Gracias por usar LSE FreeVM."
exit /b

:lang_DE
set "vm_title=LSE FreeVM"
set "vm_subtitle=Kostenlose und legale VM-Vermietungen"
set "vm_option_1=Verfugbare VMs anzeigen"
set "vm_option_2=VM mieten"
set "vm_option_3=Meine aktiven Vermietungen"
set "vm_option_0=Beenden"
set "vm_choose=Wahle eine Option"
set "vm_invalid=Ungultige Option."
set "vm_list_title=Verfugbare VMs"
set "vm_1=Ubuntu 24.04 LTS Desktop/Server - Fur Web-Entwicklung"
set "vm_2=Windows 10/11 - Fur Windows-Anwendungen"
set "vm_3=Zorin OS 18 - Fur Linux-Anfanger"
set "vm_4=Fedora 43 - Fur Entwickler und Tester"
set "vm_5=Kommt bald ..."
set "vm_legal=Alle VMs sind kostenlos und legal."
set "vm_rent_msg=Vermietungsformular wird geoffnet..."
set "vm_rentals_title=Meine aktiven Vermietungen"
set "vm_enter_username=Gib deinen Benutzernamen ein"
set "vm_empty_username=Leerer Benutzername."
set "vm_retrieving_rentals=Vermietungen werden abgerufen fur"
set "vm_no_rental=Keine Vermietung gefunden fur"
set "vm_or_unavailable=oder Service nicht verfugbar."
set "vm_goodbye=Danke, dass du LSE FreeVM nutzt."
exit /b

:lang_IT
set "vm_title=LSE FreeVM"
set "vm_subtitle=Noleggi VM Gratuiti e Legali"
set "vm_option_1=Visualizza VM Disponibili"
set "vm_option_2=Noleggia una VM"
set "vm_option_3=I Miei Noleggi Attivi"
set "vm_option_0=Esci"
set "vm_choose=Scegli un'opzione"
set "vm_invalid=Opzione non valida."
set "vm_list_title=VM Disponibili"
set "vm_1=Ubuntu 24.04 LTS Desktop/Server - Per lo sviluppo web"
set "vm_2=Windows 10/11 - Per applicazioni Windows"
set "vm_3=Zorin OS 18 - Per utenti Linux principianti"
set "vm_4=Fedora 43 - Per sviluppatori e tester"
set "vm_5=Prossimamente ..."
set "vm_legal=Tutte le VM sono gratuite e legali."
set "vm_rent_msg=Apertura modulo di noleggio..."
set "vm_rentals_title=I Miei Noleggi Attivi"
set "vm_enter_username=Inserisci il tuo nome utente"
set "vm_empty_username=Nome utente vuoto."
set "vm_retrieving_rentals=Recupero noleggi per"
set "vm_no_rental=Nossun noleggio trovato per"
set "vm_or_unavailable=o servizio non disponibile."
set "vm_goodbye=Grazie per aver utilizzato LSE FreeVM."
exit /b

:lang_PT
set "vm_title=LSE FreeVM"
set "vm_subtitle=Alugueis de VMs Gratis e Legais"
set "vm_option_1=Ver VMs Disponiveis"
set "vm_option_2=Alugar uma VM"
set "vm_option_3=Meus Alugueis Ativos"
set "vm_option_0=Sair"
set "vm_choose=Escolha uma opcao"
set "vm_invalid=Opcao invalida."
set "vm_list_title=VMs Disponiveis"
set "vm_1=Ubuntu 24.04 LTS Desktop/Server - Para desenvolvimento web"
set "vm_2=Windows 10/11 - Para aplicacoes Windows"
set "vm_3=Zorin OS 18 - Para usuarios Linux iniciantes"
set "vm_4=Fedora 43 - Para desenvolvedores e testadores"
set "vm_5=Em breve ..."
set "vm_legal=Todas as VMs sao gratuitas e legais."
set "vm_rent_msg=Abrindo formulario de aluguel..."
set "vm_rentals_title=Meus Alugueis Ativos"
set "vm_enter_username=Digite seu nome de usuario"
set "vm_empty_username=Nome de usuario vazio."
set "vm_retrieving_rentals=Recuperando alugueis para"
set "vm_no_rental=Nenhum aluguel encontrado para"
set "vm_or_unavailable=ou servico indisponivel."
set "vm_goodbye=Obrigado por usar o LSE FreeVM."
exit /b

:lang_RU
set "vm_title=LSE FreeVM"
set "vm_subtitle=Besprotnye i zakonnyh VM arend"
set "vm_option_1=Dlya dostupa VM"
set "vm_option_2=Arendovat VM"
set "vm_option_3=Moi aktivnye arenda"
set "vm_option_0=Vykhod"
set "vm_choose=Vyberite variant"
set "vm_invalid=Nepravilnyy variant."
set "vm_list_title=Dostupnyye VM"
set "vm_1=Ubuntu 24.04 LTS Desktop/Server - Dlya veb-razrabotki"
set "vm_2=Windows 10/11 - Dlya prilozheniay Windows"
set "vm_3=Zorin OS 18 - Dlya novichkov Linux"
set "vm_4=Fedora 43 - Dlya razrabotchikov i testerov"
set "vm_5=Skoro budet ..."
set "vm_legal=Vse VM besplatnye i zakonnyh."
set "vm_rent_msg=Otkryvaetsya forma arenda..."
set "vm_rentals_title=Moi aktivnye arenda"
set "vm_enter_username=Vvedite vase imya polzovatelya"
set "vm_empty_username=Pustoe imya polzovatelya."
set "vm_retrieving_rentals=Poluchenie arendy dlya"
set "vm_no_rental=Arenda ne naidena dlya"
set "vm_or_unavailable=ili usluga nedostupna."
set "vm_goodbye=Spasibo za ispolzovanie LSE FreeVM."
exit /b

:lang_JA
set "vm_title=LSE FreeVM"
set "vm_subtitle=Jiyuu na fuhou VM rental"
set "vm_option_1=Riyo shakin VM wo miru"
set "vm_option_2=VM wo rental"
set "vm_option_3=Watashi no akutibu rental"
set "vm_option_0=Shutsuryoku"
set "vm_choose=Opushon wo sentaku"
set "vm_invalid=Fukatekina opushon."
set "vm_list_title=Riyo shakin VM"
set "vm_1=Ubuntu 24.04 LTS Desktop/Server - Web kaihatsu no tame"
set "vm_2=Windows 10/11 - Windows yoyo no tame"
set "vm_3=Zorin OS 18 - Linux shoshinsha no tame"
set "vm_4=Fedora 43 - Kaihatsusha to testerano tame"
set "vm_5=Chikaichiikini ..."
set "vm_legal=Subete VM wa jiyuu to fuhou."
set "vm_rent_msg=Rental form wo aku..."
set "vm_rentals_title=Watashi no akutibu rental"
set "vm_enter_username=Username o nyuryoku"
set "vm_empty_username=Kara username."
set "vm_retrieving_rentals=Rental o yushutsu"
set "vm_no_rental=Rental ga mitsukaarimasen"
set "vm_or_unavailable=ya saabisu wa riyo dekimasen."
set "vm_goodbye=LSE FreeVM o riyou arigatou gozaimasu."
exit /b

:lang_ZH
set "vm_title=LSE FreeVM"
set "vm_subtitle=Ziyou he hefaru VM zulin"
set "vm_option_1=Cha kan keyi VM"
set "vm_option_2=Zulin yi ge VM"
set "vm_option_3=Wo de zhengzai zu li"
set "vm_option_0=Tuichu"
set "vm_choose=Xuanze yi ge xuanxiang"
set "vm_invalid=Wufa xuanxiang."
set "vm_list_title=Keyi VM"
set "vm_1=Ubuntu 24.04 LTS Desktop/Server - Yingyong yu wang zhan kaifa"
set "vm_2=Windows 10/11 - Yingyong yu Windows yingyong"
set "vm_3=Zorin OS 18 - Yingyong yu chuji Linux yonghu"
set "vm_4=Fedora 43 - Yingyong yu kaifa zhe he ceshiji"
set "vm_5=Jijiang dao lai ..."
set "vm_legal=Suoyou VM mianfei he hefaru."
set "vm_rent_msg=Daka zulin biaodanze..."
set "vm_rentals_title=Wo de zhengzai zulin"
set "vm_enter_username=Shuruyu mingzi"
set "vm_empty_username=Konp yonghu ming."
set "vm_retrieving_rentals=Huoqu zulin"
set "vm_no_rental=Weizhao zulin"
set "vm_or_unavailable=huo fuwu bu keyi."
set "vm_goodbye=Gaoxie shi yong LSE FreeVM."
exit /b

:lang_NL
set "vm_title=LSE FreeVM"
set "vm_subtitle=Gratis en Legale VM-verhuren"
set "vm_option_1=Beschikbare VMs bekijken"
set "vm_option_2=Een VM huren"
set "vm_option_3=Mijn Actieve Huurovereenkomsten"
set "vm_option_0=Afsluiten"
set "vm_choose=Kies een optie"
set "vm_invalid=Ongeldige optie."
set "vm_list_title=Beschikbare VMs"
set "vm_1=Ubuntu 24.04 LTS Desktop/Server - Voor webontwikkeling"
set "vm_2=Windows 10/11 - Voor Windows-toepassingen"
set "vm_3=Zorin OS 18 - Voor beginnende Linux-gebruikers"
set "vm_4=Fedora 43 - Voor ontwikkelaars en testers"
set "vm_5=Binnenkort beschikbaar ..."
set "vm_legal=Alle VMs zijn gratis en legaal."
set "vm_rent_msg=Huurformulier wordt geopend..."
set "vm_rentals_title=Mijn Actieve Huurovereenkomsten"
set "vm_enter_username=Voer uw gebruikersnaam in"
set "vm_empty_username=Lege gebruikersnaam."
set "vm_retrieving_rentals=Huurovereenkomsten ophalen voor"
set "vm_no_rental=Geen huurovereenkomst gevonden voor"
set "vm_or_unavailable=of service niet beschikbaar."
set "vm_goodbye=Dank u wel voor het gebruik van LSE FreeVM."
exit /b

:lang_PL
set "vm_title=LSE FreeVM"
set "vm_subtitle=Bezplatne i legalne wynajmy VM"
set "vm_option_1=Wyswietl dostepne VM"
set "vm_option_2=Wynajmij VM"
set "vm_option_3=Moje Aktywne Wynajmy"
set "vm_option_0=Wyjscie"
set "vm_choose=Wybierz opcje"
set "vm_invalid=Nieprawidlowa opcja."
set "vm_list_title=Dostepne VM"
set "vm_1=Ubuntu 24.04 LTS Desktop/Server - Do tworzenia stron"
set "vm_2=Windows 10/11 - Do aplikacji Windows"
set "vm_3=Zorin OS 18 - Dla poczatkujacych uzytkownikow Linux"
set "vm_4=Fedora 43 - Dla programistow i testerow"
set "vm_5=Niedlugo dostepne ..."
set "vm_legal=Wszystkie VMs sa bezplatne i legalne."
set "vm_rent_msg=Otwarcie formularza wynajmu..."
set "vm_rentals_title=Moje Aktywne Wynajmy"
set "vm_enter_username=Podaj swoja nazwe uzytkownika"
set "vm_empty_username=Pusta nazwa uzytkownika."
set "vm_retrieving_rentals=Pobieranie wynajmow dla"
set "vm_no_rental=Nie znaleziono wynajmu dla"
set "vm_or_unavailable=lub dostep nie dostepny."
set "vm_goodbye=Dzieki za korzystanie z LSE FreeVM."
exit /b

:lang_FR
set "vm_title=LSE FreeVM"
set "vm_subtitle=Location de VMs legales et gratuites"
set "vm_option_1=Voir les VMs disponibles"
set "vm_option_2=Louer une VM"
set "vm_option_3=Mes locations actives"
set "vm_option_0=Quitter"
set "vm_choose=Choisissez une option"
set "vm_invalid=Option invalide."
set "vm_list_title=VMs disponibles"
set "vm_1=Ubuntu 24.04 LTS Desktop/Server - Pour developpement web"
set "vm_2=Windows 10/11 - Pour applications Windows"
set "vm_3=Zorin OS 18 - Pour utilisateurs Linux debutants"
set "vm_4=Fedora 43 - Pour developpeurs et testeurs"
set "vm_5=Bientot disponible ..."
set "vm_legal=Toutes les VMs sont gratuites et legales."
set "vm_rent_msg=Ouverture du formulaire de location..."
set "vm_rentals_title=Vos locations actives"
set "vm_enter_username=Entrez votre nom d'utilisateur"
set "vm_empty_username=Nom d'utilisateur vide."
set "vm_retrieving_rentals=Recuperation des locations pour"
set "vm_no_rental=Aucune location trouvee pour"
set "vm_or_unavailable=ou service indisponible."
set "vm_goodbye=Merci d'avoir utilise LSE FreeVM."
exit /b

:detect_os_language
set "detected_language=FR"
for /f "tokens=2 delims==" %%A in ('wmic os get locale ^| findstr .'') do (
    set "os_locale=%%A"
)
set "os_locale=!os_locale: =!"

if "!os_locale!"=="40C" set "detected_language=FR"
if "!os_locale!"=="C0C" set "detected_language=FR"
if "!os_locale!"=="80C" set "detected_language=FR"
if "!os_locale!"=="100C" set "detected_language=FR"
if "!os_locale!"=="140C" set "detected_language=FR"
if "!os_locale!"=="180C" set "detected_language=FR"
if "!os_locale!"=="1C0C" set "detected_language=FR"

if "!os_locale!"=="409" set "detected_language=EN"
if "!os_locale!"=="809" set "detected_language=EN"
if "!os_locale!"=="C09" set "detected_language=EN"
if "!os_locale!"=="1009" set "detected_language=EN"
if "!os_locale!"=="1409" set "detected_language=EN"
if "!os_locale!"=="1809" set "detected_language=EN"
if "!os_locale!"=="1C09" set "detected_language=EN"
if "!os_locale!"=="2009" set "detected_language=EN"
if "!os_locale!"=="2409" set "detected_language=EN"
if "!os_locale!"=="2809" set "detected_language=EN"
if "!os_locale!"=="2C09" set "detected_language=EN"
if "!os_locale!"=="3009" set "detected_language=EN"
if "!os_locale!"=="3409" set "detected_language=EN"

if "!os_locale!"=="C0A" set "detected_language=ES"
if "!os_locale!"=="40A" set "detected_language=ES"
if "!os_locale!"=="80A" set "detected_language=ES"
if "!os_locale!"=="100A" set "detected_language=ES"
if "!os_locale!"=="140A" set "detected_language=ES"
if "!os_locale!"=="180A" set "detected_language=ES"
if "!os_locale!"=="1C0A" set "detected_language=ES"
if "!os_locale!"=="200A" set "detected_language=ES"

if "!os_locale!"=="407" set "detected_language=DE"
if "!os_locale!"=="807" set "detected_language=DE"
if "!os_locale!"=="C07" set "detected_language=DE"
if "!os_locale!"=="1007" set "detected_language=DE"
if "!os_locale!"=="1407" set "detected_language=DE"

if "!os_locale!"=="410" set "detected_language=IT"
if "!os_locale!"=="810" set "detected_language=IT"

if "!os_locale!"=="416" set "detected_language=PT"
if "!os_locale!"=="816" set "detected_language=PT"

if "!os_locale!"=="419" set "detected_language=RU"
if "!os_locale!"=="819" set "detected_language=RU"

if "!os_locale!"=="411" set "detected_language=JA"

if "!os_locale!"=="404" set "detected_language=ZH"
if "!os_locale!"=="804" set "detected_language=ZH"
if "!os_locale!"=="C04" set "detected_language=ZH"

if "!os_locale!"=="413" set "detected_language=NL"
if "!os_locale!"=="813" set "detected_language=NL"

if "!os_locale!"=="415" set "detected_language=PL"

exit /b
