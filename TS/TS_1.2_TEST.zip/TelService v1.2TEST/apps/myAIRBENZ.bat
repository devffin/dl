@echo off
title myAIRBENZ
setlocal enabledelayedexpansion
chcp 65001 >nul

if not exist "..\config\lang.txt" (
    if not exist "..\config" mkdir "..\config"
    call :detect_os_language
    echo language=!detected_language!>"..\config\lang.txt"
)

call :load_language

:menu
cls
echo.
echo ====================================================
echo !airb_welcome!
echo !airb_subtitle!
echo ====================================================
echo.
echo ====================================================
echo !airb_news!
echo.
powershell -command "Invoke-WebRequest -Uri 'https://devffin.github.io/dl/ma-actus.txt' -OutFile '%temp%\actus.txt'" 2>nul
if errorlevel 1 (
    echo !airb_error_download!
)
type "%temp%\actus.txt" 2>nul || echo !airb_no_news!
del "%temp%\actus.txt" 2>nul
echo.
echo ====================================================
echo.
echo !airb_press_key!
pause >nul
exit /b 0

:load_language
set "lang=FR"
if exist "..\config\lang.txt" (
    for /f "tokens=2 delims==" %%A in ('type ..\config\lang.txt ^| findstr /i "^language"') do (
        set "lang=%%A"
    )
)
set "lang=!lang: =!"

if /i "!lang!"=="EN" goto :lang_EN
if /i "!lang!"=="ES" goto :lang_ES
if /i "!lang!"=="DE" goto :lang_DE
if /i "!lang!"=="IT" goto :lang_IT
if /i "!lang!"=="PT" goto :lang_PT
if /i "!lang!"=="RU" goto :lang_RU
if /i "!lang!"=="JA" goto :lang_JA
if /i "!lang!"=="ZH" goto :lang_ZH
if /i "!lang!"=="NL" goto :lang_NL
if /i "!lang!"=="PL" goto :lang_PL
goto :lang_FR

:lang_EN
set "airb_welcome=Welcome to myAIRBENZ!"
set "airb_subtitle=The retro community app"
set "airb_news=News:"
set "airb_error_download=Error downloading news. Check your internet connection."
set "airb_no_news=No news available."
set "airb_press_key=Press a key to return to menu..."
exit /b

:lang_ES
set "airb_welcome=¡Bienvenido a myAIRBENZ!"
set "airb_subtitle=La aplicacion de la comunidad retro"
set "airb_news=Noticias:"
set "airb_error_download=Error descargando noticias. Verifique su conexion a Internet."
set "airb_no_news=Sin noticias disponibles."
set "airb_press_key=Presione una tecla para volver al menu..."
exit /b

:lang_DE
set "airb_welcome=Willkommen bei myAIRBENZ!"
set "airb_subtitle=Die Retro-Community-App"
set "airb_news=Neuigkeiten:"
set "airb_error_download=Fehler beim Herunterladen von Nachrichten. Uberprufen Sie Ihre Internetverbindung."
set "airb_no_news=Keine Nachrichten verfugbar."
set "airb_press_key=Druke eine taste, um zum menu zuruckzukehren..."
exit /b

:lang_IT
set "airb_welcome=Benvenuto a myAIRBENZ!"
set "airb_subtitle=L'app della comunita retro"
set "airb_news=Notizie:"
set "airb_error_download=Errore durante il download delle notizie. Verificare la connessione Internet."
set "airb_no_news=Nessuna notizia disponibile."
set "airb_press_key=Premi un tasto per tornare al menu..."
exit /b

:lang_PT
set "airb_welcome=Bem-vindo ao myAIRBENZ!"
set "airb_subtitle=O aplicativo da comunidade retro"
set "airb_news=Noticias:"
set "airb_error_download=Erro ao baixar noticias. Verifique sua conexao com a Internet."
set "airb_no_news=Nenhuma noticia disponivel."
set "airb_press_key=Pressione uma tecla para voltar ao menu..."
exit /b

:lang_RU
set "airb_welcome=Dobro pozhalovat v myAIRBENZ!"
set "airb_subtitle=Prilozhenie retro-soobshchestva"
set "airb_news=Novosti:"
set "airb_error_download=Oshibka pri zagruzke novostey. Proverite vasha internet-soedineniya."
set "airb_no_news=Novostey ne dostupno."
set "airb_press_key=Spayte klavishu dlya vozvrata v menyu..."
exit /b

:lang_JA
set "airb_welcome=myAIRBENZ e yokoso!"
set "airb_subtitle=Retro komyuniti apuri"
set "airb_news=Nyuusu:"
set "airb_error_download=Nyuusu no download erotaa. Intanet kankei o kakunin shite kudasai."
set "airb_no_news=Nyuusu wa arimasen."
set "airb_press_key=Suupatsu wo shite menu ni modorimasu..."
exit /b

:lang_ZH
set "airb_welcome=Huanying dao myAIRBENZ!"
set "airb_subtitle=Retro shequ yingyong"
set "airb_news=Xinwen:"
set "airb_error_download=Xinwen xiade shi bao. Jingcha Internet lianjie."
set "airb_no_news=Meiyou xinwen."
set "airb_press_key=Yi an ren yi ge jian hui dao caidan..."
exit /b

:lang_NL
set "airb_welcome=Welkom bij myAIRBENZ!"
set "airb_subtitle=De retro-community-app"
set "airb_news=Nieuws:"
set "airb_error_download=Fout bij het downloaden van nieuws. Controleer uw internetverbinding."
set "airb_no_news=Geen nieuws beschikbaar."
set "airb_press_key=Druk op een toets om naar menu te gaan..."
exit /b

:lang_PL
set "airb_welcome=Wazcie do myAIRBENZ!"
set "airb_subtitle=Aplikacja spolecznosci retro"
set "airb_news=Wiadomosci:"
set "airb_error_download=Blad podczas pobierania wiadomosci. Sprawdz polaczenie Internet."
set "airb_no_news=Brak wiadomosci."
set "airb_press_key=Nacisnij klawisz aby powrocic do menu..."
exit /b

:lang_FR
set "airb_welcome=Bienvenue sur myAIRBENZ!"
set "airb_subtitle=L'appli de la communaute retro"
set "airb_news=Actualites:"
set "airb_error_download=Erreur lors du telechargement des actualites. Verifiez votre connexion internet."
set "airb_no_news=Aucune actualite disponible."
set "airb_press_key=Appuyez sur une touche pour revenir au menu..."
exit /b

:detect_os_language
set "detected_language=FR"
for /f "tokens=2 delims==" %%A in ('wmic os get locale ^| findstr .'') do (
    set "os_locale=%%A"
)
set "os_locale=!os_locale: =!"

if "!os_locale!"=="40C" set "detected_language=FR"
if "!os_locale!"=="C0C" set "detected_language=FR"
if "!os_locale!"=="80C" set "detected_language=FR"
if "!os_locale!"=="100C" set "detected_language=FR"
if "!os_locale!"=="140C" set "detected_language=FR"
if "!os_locale!"=="180C" set "detected_language=FR"
if "!os_locale!"=="1C0C" set "detected_language=FR"

if "!os_locale!"=="409" set "detected_language=EN"
if "!os_locale!"=="809" set "detected_language=EN"
if "!os_locale!"=="C09" set "detected_language=EN"
if "!os_locale!"=="1009" set "detected_language=EN"
if "!os_locale!"=="1409" set "detected_language=EN"
if "!os_locale!"=="1809" set "detected_language=EN"
if "!os_locale!"=="1C09" set "detected_language=EN"
if "!os_locale!"=="2009" set "detected_language=EN"
if "!os_locale!"=="2409" set "detected_language=EN"
if "!os_locale!"=="2809" set "detected_language=EN"
if "!os_locale!"=="2C09" set "detected_language=EN"
if "!os_locale!"=="3009" set "detected_language=EN"
if "!os_locale!"=="3409" set "detected_language=EN"

if "!os_locale!"=="C0A" set "detected_language=ES"
if "!os_locale!"=="40A" set "detected_language=ES"
if "!os_locale!"=="80A" set "detected_language=ES"
if "!os_locale!"=="100A" set "detected_language=ES"
if "!os_locale!"=="140A" set "detected_language=ES"
if "!os_locale!"=="180A" set "detected_language=ES"
if "!os_locale!"=="1C0A" set "detected_language=ES"
if "!os_locale!"=="200A" set "detected_language=ES"

if "!os_locale!"=="407" set "detected_language=DE"
if "!os_locale!"=="807" set "detected_language=DE"
if "!os_locale!"=="C07" set "detected_language=DE"
if "!os_locale!"=="1007" set "detected_language=DE"
if "!os_locale!"=="1407" set "detected_language=DE"

if "!os_locale!"=="410" set "detected_language=IT"
if "!os_locale!"=="810" set "detected_language=IT"

if "!os_locale!"=="416" set "detected_language=PT"
if "!os_locale!"=="816" set "detected_language=PT"

if "!os_locale!"=="419" set "detected_language=RU"
if "!os_locale!"=="819" set "detected_language=RU"

if "!os_locale!"=="411" set "detected_language=JA"

if "!os_locale!"=="404" set "detected_language=ZH"
if "!os_locale!"=="804" set "detected_language=ZH"
if "!os_locale!"=="C04" set "detected_language=ZH"

if "!os_locale!"=="413" set "detected_language=NL"
if "!os_locale!"=="813" set "detected_language=NL"

if "!os_locale!"=="415" set "detected_language=PL"

exit /b