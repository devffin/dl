@echo off
title Musique
setlocal enabledelayedexpansion
chcp 65001 >nul

cd /d "%~dp0"

REM Create parent config if needed
if not exist "..\config\lang.txt" (
    if not exist "..\config" mkdir "..\config"
    call :detect_os_language
    echo language=!detected_language!>"..\config\lang.txt"
)

REM Load language
call :load_language

REM Check for Python
where python >nul 2>nul
if errorlevel 1 (
    echo !music_python_required!
    set /p pyinstall="!music_install_python_yn!: "
    if /i "!pyinstall!"=="O" (
        echo !music_installing_python!...
        powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.12.6/python-3.12.6-amd64.exe' -OutFile 'python_installer.exe'" 2>nul
        if not errorlevel 1 (
            start /wait python_installer.exe /quiet InstallAllUsers=1 PrependPath=1
            del python_installer.exe
            where python >nul 2>nul
            if not errorlevel 1 (
                echo !music_python_success!
            ) else (
                echo !music_python_error!
                pause
                exit /b
            )
        ) else (
            echo !music_download_error!
            pause
            exit /b
        )
    ) else (
        echo !music_install_cancelled!
        pause
        exit /b
    )
)

:MENU
cls
echo  !music_player_title!
echo =============================================
echo.
echo 1. !music_play_from_link!
echo 2. !music_quit!
echo.
set /p choice="!music_choose_option!: "

if "%choice%"=="1" goto PLAY
if "%choice%"=="2" exit /b
goto MENU

:PLAY
cls
del temp_music.* 2>nul
del downloaded_before.txt 2>nul

REM Download yt-dlp if not present
if not exist yt-dlp.exe (
    echo !music_downloading_ytdlp!...
    curl -L -o yt-dlp.exe https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe 2>nul
    if errorlevel 1 (
        echo !music_ytdlp_error!
        pause
        goto MENU
    )
)

REM Download ffmpeg if not present
if not exist ffmpeg.exe (
    echo !music_downloading_ffmpeg!...
    curl -L -o ffmpeg.zip https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip 2>nul
    if errorlevel 1 (
        echo !music_ffmpeg_error!
        pause
        goto MENU
    )
    powershell -command "Expand-Archive -Path ffmpeg.zip -DestinationPath . -Force" 2>nul
    if errorlevel 1 (
        echo !music_ffmpeg_extract_error!
        del ffmpeg.zip
        pause
        goto MENU
    )
    set "ffmpeg_dir="
    for /d %%D in ("ffmpeg-*") do (
        if exist "%%~fD\bin\ffmpeg.exe" set "ffmpeg_dir=%%~fD"
    )
    if not defined ffmpeg_dir (
        echo !music_ffmpeg_folder_error!
        del ffmpeg.zip
        pause
        goto MENU
    )
    move "!ffmpeg_dir!\bin\ffmpeg.exe" . 2>nul
    move "!ffmpeg_dir!\bin\ffprobe.exe" . 2>nul
    rmdir /s /q "!ffmpeg_dir!" 2>nul
    del ffmpeg.zip
)

REM Check for spotdl
echo Verification de spotdl...
python -c "import spotdl" 2>nul
if errorlevel 1 (
    echo Installation de spotdl...
    python -m pip install spotdl --quiet 2>nul
    if errorlevel 1 (
        echo Erreur lors de l'installation de spotdl.
    )
)

echo.
echo Entrez le lien de la musique (YouTube, Spotify, etc.):
set /p url=

if "!url!"=="" (
    echo Aucun lien fourni.
    pause
    goto MENU
)

echo.
echo Traitement du lien...

REM Check for YouTube
call :check_youtube
if !is_youtube!==1 (
    call :download_youtube
    goto MENU
)

REM Check for Spotify
call :check_spotify
if !is_spotify!==1 (
    call :download_spotify
    goto MENU
)

REM Unsupported link
echo Type de lien non supporté. Tentative de lecture directe...
start "" "!url!"

echo.
echo Appuyez sur une touche pour revenir au menu...
pause >nul
goto MENU


:check_youtube
set "is_youtube=0"
if not "!url:youtube.com=!"=="!url!" (
    set "is_youtube=1"
) else if not "!url:youtu.be=!"=="!url!" (
    set "is_youtube=1"
)
exit /b

:check_spotify
set "is_spotify=0"
if not "!url:spotify.com=!"=="!url!" (
    set "is_spotify=1"
)
exit /b

:download_youtube
echo !music_youtube_detected! !music_downloading!...
yt-dlp -q -x --audio-format mp3 -o "temp_music.%%(ext)s" "!url!" >nul 2>&1
if errorlevel 1 (
    echo !music_download_error_msg!
    del temp_music.* 2>nul
    pause
    exit /b
)

for %%f in (temp_music.*) do (
    echo !music_playing! %%f
    start "" "%%f"
    set /p save="!music_save_yn!: "
    if /i "!save!"=="O" (
        set /p path="!music_save_path!: "
        if not exist "!path!" (
            mkdir "!path!" 2>nul
        )
        set /p filename="!music_save_filename!: "
        set "ext=%%~xf"
        move "%%f" "!path!\!filename!!ext!" 2>nul
        if errorlevel 1 (
            echo !music_save_error!
            del "%%f" 2>nul
        ) else (
            echo !music_saved_at! !path!\!filename!!ext!
        )
    )
)
del temp_music.* 2>nul
exit /b

:download_spotify
echo !music_spotify_detected! !music_downloading_spotdl!...
(for %%f in (*.mp3 *.m4a *.flac) do @echo %%f) > downloaded_before.txt 2>nul
spotdl "!url!" -q >nul 2>&1
if errorlevel 1 (
    echo !music_download_error_msg!
    del downloaded_before.txt 2>nul
    pause
    exit /b
)
for %%f in (*.mp3 *.m4a *.flac) do (
    findstr /x "%%f" downloaded_before.txt >nul 2>&1
    if errorlevel 1 (
        echo !music_playing! %%f
        start "" "%%f"
    )
)
del downloaded_before.txt 2>nul
exit /b

:load_language
set "lang=FR"
if exist "..\config\lang.txt" (
    for /f "tokens=2 delims==" %%A in ('type ..\config\lang.txt ^| findstr /i "^language"') do (
        set "lang=%%A"
    )
)
set "lang=!lang: =!"

if /i "!lang!"=="EN" goto :lang_EN
if /i "!lang!"=="ES" goto :lang_ES
if /i "!lang!"=="DE" goto :lang_DE
if /i "!lang!"=="IT" goto :lang_IT
if /i "!lang!"=="PT" goto :lang_PT
if /i "!lang!"=="RU" goto :lang_RU
if /i "!lang!"=="JA" goto :lang_JA
if /i "!lang!"=="ZH" goto :lang_ZH
if /i "!lang!"=="NL" goto :lang_NL
if /i "!lang!"=="PL" goto :lang_PL
goto :lang_FR

:lang_EN
set "music_python_required=Python is required for this application."
set "music_install_python_yn=Install Python now (Y/N)"
set "music_installing_python=Installing Python"
set "music_python_success=Python installed successfully."
set "music_python_error=Python was not installed correctly. Please install it manually."
set "music_download_error=Error downloading Python. Check your internet connection."
set "music_install_cancelled=Installation cancelled."
set "music_player_title=Music - Music player from a link"
set "music_play_from_link=Play from a link (YouTube, etc.)"
set "music_quit=Quit"
set "music_choose_option=Choose an option"
set "music_downloading_ytdlp=Downloading yt-dlp"
set "music_ytdlp_error=Error downloading yt-dlp. Check your internet connection."
set "music_downloading_ffmpeg=Downloading ffmpeg"
set "music_ffmpeg_error=Error downloading ffmpeg."
set "music_ffmpeg_extract_error=Error extracting ffmpeg."
set "music_ffmpeg_folder_error=ffmpeg folder not found after extraction."
set "music_youtube_detected=YouTube link detected."
set "music_downloading=Downloading and playing"
set "music_download_error_msg=Error downloading."
set "music_playing=Playing"
set "music_save_yn=Save (Y/N)"
set "music_save_path=Enter save path (ex: C:\Music\)"
set "music_save_filename=Enter filename (without extension)"
set "music_save_error=Error saving file."
set "music_saved_at=File saved at"
set "music_spotify_detected=Spotify link detected."
set "music_downloading_spotdl=Downloading with spotdl"
exit /b

:lang_ES
set "music_python_required=Python es requerido para esta aplicacion."
set "music_install_python_yn=Instalar Python ahora (S/N)"
set "music_installing_python=Instalando Python"
set "music_python_success=Python instalado correctamente."
set "music_python_error=Python no se instalo correctamente. Por favor, instalelo manualmente."
set "music_download_error=Error descargando Python. Verifique su conexion a Internet."
set "music_install_cancelled=Instalacion cancelada."
set "music_player_title=Musica - Reproductor de musica desde un enlace"
set "music_play_from_link=Reproducir desde un enlace (YouTube, etc.)"
set "music_quit=Salir"
set "music_choose_option=Elija una opcion"
set "music_downloading_ytdlp=Descargando yt-dlp"
set "music_ytdlp_error=Error descargando yt-dlp. Verifique su conexion a Internet."
set "music_downloading_ffmpeg=Descargando ffmpeg"
set "music_ffmpeg_error=Error descargando ffmpeg."
set "music_ffmpeg_extract_error=Error extrayendo ffmpeg."
set "music_ffmpeg_folder_error=Carpeta ffmpeg no encontrada despues de la extraccion."
set "music_youtube_detected=Enlace de YouTube detectado."
set "music_downloading=Descargando y reproduciendo"
set "music_download_error_msg=Error descargando."
set "music_playing=Reproduciendo"
set "music_save_yn=Guardar (S/N)"
set "music_save_path=Ingrese la ruta de guardado (ej: C:\Musica\)"
set "music_save_filename=Ingrese el nombre del archivo (sin extension)"
set "music_save_error=Error guardando archivo."
set "music_saved_at=Archivo guardado en"
set "music_spotify_detected=Enlace de Spotify detectado."
set "music_downloading_spotdl=Descargando con spotdl"
exit /b

:lang_DE
set "music_python_required=Python ist fur diese Anwendung erforderlich."
set "music_install_python_yn=Python jetzt installieren (J/N)"
set "music_installing_python=Python wird installiert"
set "music_python_success=Python erfolgreich installiert."
set "music_python_error=Python wurde nicht korrekt installiert. Bitte installieren Sie es manuell."
set "music_download_error=Fehler beim Herunterladen von Python. Uberprufen Sie Ihre Internetverbindung."
set "music_install_cancelled=Installation abgebrochen."
set "music_player_title=Musik - Musikplayer von einem Link"
set "music_play_from_link=Von einem Link abspielen (YouTube, etc.)"
set "music_quit=Beenden"
set "music_choose_option=Wahlen Sie eine Option"
set "music_downloading_ytdlp=yt-dlp wird heruntergeladen"
set "music_ytdlp_error=Fehler beim Herunterladen von yt-dlp. Uberprufen Sie Ihre Internetverbindung."
set "music_downloading_ffmpeg=ffmpeg wird heruntergeladen"
set "music_ffmpeg_error=Fehler beim Herunterladen von ffmpeg."
set "music_ffmpeg_extract_error=Fehler beim Extrahieren von ffmpeg."
set "music_ffmpeg_folder_error=ffmpeg-Ordner nicht nach Extraktion gefunden."
set "music_youtube_detected=YouTube-Link erkannt."
set "music_downloading=Herunterladen und Abspielen"
set "music_download_error_msg=Fehler beim Herunterladen."
set "music_playing=Abspielen"
set "music_save_yn=Speichern (J/N)"
set "music_save_path=Geben Sie den Speicherpfad ein (z.B.: C:\Musik\)"
set "music_save_filename=Geben Sie den Dateinamen ein (ohne Erweiterung)"
set "music_save_error=Fehler beim Speichern der Datei."
set "music_saved_at=Datei gespeichert unter"
set "music_spotify_detected=Spotify-Link erkannt."
set "music_downloading_spotdl=Mit spotdl herunterladen"
exit /b

:lang_IT
set "music_python_required=Python e richiesto per questa applicazione."
set "music_install_python_yn=Installare Python ora (S/N)"
set "music_installing_python=Installazione di Python"
set "music_python_success=Python installato correttamente."
set "music_python_error=Python non e stato installato correttamente. Si prega di installarlo manualmente."
set "music_download_error=Errore durante il download di Python. Verificare la connessione Internet."
set "music_install_cancelled=Installazione annullata."
set "music_player_title=Musica - Lettore musicale da un collegamento"
set "music_play_from_link=Riproduci da un collegamento (YouTube, ecc.)"
set "music_quit=Esci"
set "music_choose_option=Scegli un'opzione"
set "music_downloading_ytdlp=Download di yt-dlp"
set "music_ytdlp_error=Errore durante il download di yt-dlp. Verificare la connessione Internet."
set "music_downloading_ffmpeg=Download di ffmpeg"
set "music_ffmpeg_error=Errore durante il download di ffmpeg."
set "music_ffmpeg_extract_error=Errore durante l'estrazione di ffmpeg."
set "music_ffmpeg_folder_error=Cartella ffmpeg non trovata dopo l'estrazione."
set "music_youtube_detected=Collegamento YouTube rilevato."
set "music_downloading=Download e riproduzione"
set "music_download_error_msg=Errore durante il download."
set "music_playing=Riproduzione di"
set "music_save_yn=Salva (S/N)"
set "music_save_path=Immettere il percorso di salvataggio (es: C:\Musica\)"
set "music_save_filename=Immettere il nome del file (senza estensione)"
set "music_save_error=Errore durante il salvataggio del file."
set "music_saved_at=File salvato in"
set "music_spotify_detected=Collegamento Spotify rilevato."
set "music_downloading_spotdl=Download con spotdl"
exit /b

:lang_PT
set "music_python_required=Python e necessario para este aplicativo."
set "music_install_python_yn=Instalar Python agora (S/N)"
set "music_installing_python=Instalando Python"
set "music_python_success=Python instalado com sucesso."
set "music_python_error=Python nao foi instalado corretamente. Por favor, instale-o manualmente."
set "music_download_error=Erro ao baixar Python. Verifique sua conexao com a Internet."
set "music_install_cancelled=Instalacao cancelada."
set "music_player_title=Musica - Reprodutor de musica a partir de um link"
set "music_play_from_link=Reproduzir a partir de um link (YouTube, etc.)"
set "music_quit=Sair"
set "music_choose_option=Escolha uma opcao"
set "music_downloading_ytdlp=Baixando yt-dlp"
set "music_ytdlp_error=Erro ao baixar yt-dlp. Verifique sua conexao com a Internet."
set "music_downloading_ffmpeg=Baixando ffmpeg"
set "music_ffmpeg_error=Erro ao baixar ffmpeg."
set "music_ffmpeg_extract_error=Erro ao extrair ffmpeg."
set "music_ffmpeg_folder_error=Pasta ffmpeg nao encontrada apos a extracao."
set "music_youtube_detected=Link do YouTube detectado."
set "music_downloading=Baixando e reproduzindo"
set "music_download_error_msg=Erro ao baixar."
set "music_playing=Reproduzindo"
set "music_save_yn=Salvar (S/N)"
set "music_save_path=Insira o caminho de salvatagem (ex: C:\Musica\)"
set "music_save_filename=Insira o nome do arquivo (sem extensao)"
set "music_save_error=Erro ao salvar arquivo."
set "music_saved_at=Arquivo salvo em"
set "music_spotify_detected=Link do Spotify detectado."
set "music_downloading_spotdl=Baixando com spotdl"
exit /b

:lang_RU
set "music_python_required=Python trebuyet dlya etogo prilozheniya."
set "music_install_python_yn=Ustanovit Python seychas (D/N)"
set "music_installing_python=Ustanovka Python"
set "music_python_success=Python uspeshno ustanovlen."
set "music_python_error=Python ne byl ustanovlen pravilno. Pozhaluysta, ustanovite ego vruchnuyu."
set "music_download_error=Oshibka pri zagruzke Python. Proverite vasha internet-soedineniya."
set "music_install_cancelled=Установка otmenyena."
set "music_player_title=Muzyka - Muzykalniy pleer iz ssylki"
set "music_play_from_link=Vosproizvodity iz ssylki (YouTube, i.d.)"
set "music_quit=Vykhod"
set "music_choose_option=Vyberyty variant"
set "music_downloading_ytdlp=Zagruzka yt-dlp"
set "music_ytdlp_error=Oshibka pri zagruzke yt-dlp. Proverite vasha internet-soedineniya."
set "music_downloading_ffmpeg=Zagruzka ffmpeg"
set "music_ffmpeg_error=Oshibka pri zagruzke ffmpeg."
set "music_ffmpeg_extract_error=Oshibka pri izvlechenii ffmpeg."
set "music_ffmpeg_folder_error=Papka ffmpeg ne naidena posle izvlecheniya."
set "music_youtube_detected=Ssylka YouTube obnaruzhena."
set "music_downloading=Zagruzka i vosproizvedenie"
set "music_download_error_msg=Oshibka pri zagruzke."
set "music_playing=Vosproizvedenie"
set "music_save_yn=Sohranity (D/N)"
set "music_save_path=Vvedite put sohraneniya (npr: C:\Muzyka\)"
set "music_save_filename=Vvedite imya fayla (bez rasshireniya)"
set "music_save_error=Oshibka pri sohranenii fayla."
set "music_saved_at=Fayl sohran v"
set "music_spotify_detected=Ssylka Spotify obnaruzhena."
set "music_downloading_spotdl=Zagruzka s spotdl"
exit /b

:lang_JA
set "music_python_required=Kono aopuri ni wa Python ga hitsuyou desu."
set "music_install_python_yn=Ima Python o insutoru shimasu ka (H/I)"
set "music_installing_python=Python o insutoro chuu"
set "music_python_success=Python ga seikoku ni insutoro saremashita."
set "music_python_error=Python ga tadashik insutoru sarenakatta. Shokutai de insutoro shite kudasai."
set "music_download_error=Python no download erotaa. Intanet kankei o kakunin shite kudasai."
set "music_install_cancelled=Insutoro ga kyanseru saremashita."
set "music_player_title=Ongaku - Link kara no ongaku purea"
set "music_play_from_link=Link kara saisei (YouTube, nado)"
set "music_quit=Shutsuryoku"
set "music_choose_option=Opushon o sentaku"
set "music_downloading_ytdlp=yt-dlp o download chuu"
set "music_ytdlp_error=yt-dlp no download erotaa. Intanet kankei o kakunin shite kudasai."
set "music_downloading_ffmpeg=ffmpeg o download chuu"
set "music_ffmpeg_error=ffmpeg no download erotaa."
set "music_ffmpeg_extract_error=ffmpeg no chuushutsu erotaa."
set "music_ffmpeg_folder_error=Chuushutsu go ffmpeg folder ga mitsukaarimasen."
set "music_youtube_detected=YouTube link ga kentou saremashita."
set "music_downloading=Download shite saisei"
set "music_download_error_msg=Download erotaa."
set "music_playing=Saisei chuu"
set "music_save_yn=Hozon suru (H/I)"
set "music_save_path=Hozon basho o nyuryoku (rei: C:\Ongaku\)"
set "music_save_filename=Fail mei o nyuryoku (kakuchou nashi)"
set "music_save_error=Fail hozon erotaa."
set "music_saved_at=Fail wa hozonzai"
set "music_spotify_detected=Spotify link ga kentou saremashita."
set "music_downloading_spotdl=spotdl de download"
exit /b

:lang_ZH
set "music_python_required=Gai yingyong yaoqiu Python."
set "music_install_python_yn=Xianzai anzhuang Python (S/F)"
set "music_installing_python=Python anzhuang zhong"
set "music_python_success=Python chengong anzhuang."
set "music_python_error=Python wei anzhuang zhengque. Qing shougong anzhuang."
set "music_download_error=Xiade Python shi bao. Jingcha Internet lianjie."
set "music_install_cancelled=Anzhuang quxiao."
set "music_player_title=Yinyue - Cong lianjie bo fang yin yue"
set "music_play_from_link=Cong lianjie bo fang (YouTube deng)"
set "music_quit=Tuichu"
set "music_choose_option=Xuanze xuanxiang"
set "music_downloading_ytdlp=Xiade yt-dlp"
set "music_ytdlp_error=Xiade yt-dlp shi bao. Jingcha Internet lianjie."
set "music_downloading_ffmpeg=Xiade ffmpeg"
set "music_ffmpeg_error=Xiade ffmpeg shi bao."
set "music_ffmpeg_extract_error=Jiequa ffmpeg shi bao."
set "music_ffmpeg_folder_error=Jiequa hou ffmpeg wen jian jia weizhaodao."
set "music_youtube_detected=YouTube lianjie yi jiance."
set "music_downloading=Xiade bing bo fang"
set "music_download_error_msg=Xiade shi bao."
set "music_playing=Bo fang zhong"
set "music_save_yn=Baocun (S/F)"
set "music_save_path=Shurubaocun jinglu (chu: C:\Yinyue\)"
set "music_save_filename=Shuru wenjian ming (wu huozhan)"
set "music_save_error=Baocun wenjian shi bao."
set "music_saved_at=Wenjian baocun yu"
set "music_spotify_detected=Spotify lianjie yi jiance."
set "music_downloading_spotdl=Yong spotdl xiade"
exit /b

:lang_NL
set "music_python_required=Python is vereist voor deze toepassing."
set "music_install_python_yn=Python nu installeren (J/N)"
set "music_installing_python=Python wordt geinstalleerd"
set "music_python_success=Python succesvol geinstalleerd."
set "music_python_error=Python is niet correct genstalleerd. Installeer het alstublieft handmatig."
set "music_download_error=Fout bij het downloaden van Python. Controleer uw internetverbinding."
set "music_install_cancelled=Installatie geannuleerd."
set "music_player_title=Muziek - Muziekspeler van een koppeling"
set "music_play_from_link=Afspelen van een koppeling (YouTube, enz.)"
set "music_quit=Afsluiten"
set "music_choose_option=Kies een optie"
set "music_downloading_ytdlp=yt-dlp wordt gedownload"
set "music_ytdlp_error=Fout bij het downloaden van yt-dlp. Controleer uw internetverbinding."
set "music_downloading_ffmpeg=ffmpeg wordt gedownload"
set "music_ffmpeg_error=Fout bij het downloaden van ffmpeg."
set "music_ffmpeg_extract_error=Fout bij het uitpakken van ffmpeg."
set "music_ffmpeg_folder_error=ffmpeg-map niet gevonden na extractie."
set "music_youtube_detected=YouTube-koppeling gedetecteerd."
set "music_downloading=Downloaden en afspelen"
set "music_download_error_msg=Downloadfout."
set "music_playing=Afspelen van"
set "music_save_yn=Opslaan (J/N)"
set "music_save_path=Voer opslag in (b.v.: C:\Muziek\)"
set "music_save_filename=Voer bestandsnaam in (zonder extensie)"
set "music_save_error=Fout bij het opslaan van bestand."
set "music_saved_at=Bestand opgeslagen in"
set "music_spotify_detected=Spotify-koppeling gedetecteerd."
set "music_downloading_spotdl=Downloaden met spotdl"
exit /b

:lang_PL
set "music_python_required=Python jest wymagany dla tej aplikacji."
set "music_install_python_yn=Zainstalowar Python teraz (T/N)"
set "music_installing_python=Instalowanie Python"
set "music_python_success=Python zainstalowany pomyslnie."
set "music_python_error=Python nie zostal zainstalowany prawidlowo. Zainstaluj go recznie."
set "music_download_error=Blad podczas pobierania Python. Sprawdz polaczenie Internet."
set "music_install_cancelled=Instalacja anulowana."
set "music_player_title=Muzyka - Odtwarzacz muzyki z lacza"
set "music_play_from_link=Odtwarzaj z lacza (YouTube, itp.)"
set "music_quit=Wyjscie"
set "music_choose_option=Wybierz opcje"
set "music_downloading_ytdlp=Pobieranie yt-dlp"
set "music_ytdlp_error=Blad podczas pobierania yt-dlp. Sprawdz polaczenie Internet."
set "music_downloading_ffmpeg=Pobieranie ffmpeg"
set "music_ffmpeg_error=Blad podczas pobierania ffmpeg."
set "music_ffmpeg_extract_error=Blad podczas rozpakowywania ffmpeg."
set "music_ffmpeg_folder_error=Folder ffmpeg nie znaleziony po rozpakowaniu."
set "music_youtube_detected=Lacze YouTube wykryte."
set "music_downloading=Pobieranie i odtwarzanie"
set "music_download_error_msg=Blad pobierania."
set "music_playing=Odtwarzanie"
set "music_save_yn=Zapisz (T/N)"
set "music_save_path=Podaj sciezke zapisu (np: C:\Muzyka\)"
set "music_save_filename=Podaj nazwe pliku (bez rozszerzenia)"
set "music_save_error=Blad podczas zapisywania pliku."
set "music_saved_at=Plik zapisany w"
set "music_spotify_detected=Lacze Spotify wykryte."
set "music_downloading_spotdl=Pobieranie przy uzyciu spotdl"
exit /b
set "music_python_required=Python est requis pour cette application."
set "music_install_python_yn=Installer Python maintenant (O/N)"
set "music_installing_python=Installation de Python"
set "music_python_success=Python installe avec succes."
set "music_python_error=Python n'a pas ete installe correctement. Veuillez l'installer manuellement."
set "music_download_error=Erreur lors du telechargement de Python. Verifiez votre connexion internet."
set "music_install_cancelled=Installation annulee."
set "music_player_title=Musique - Lecteur de musique depuis un lien"
set "music_play_from_link=Jouer depuis un lien (YouTube, etc.)"
set "music_quit=Quitter"
set "music_choose_option=Choisissez une option"
set "music_downloading_ytdlp=Telechargement de yt-dlp"
set "music_ytdlp_error=Erreur lors du telechargement de yt-dlp. Verifiez votre connexion internet."
set "music_downloading_ffmpeg=Telechargement de ffmpeg"
set "music_ffmpeg_error=Erreur lors du telechargement de ffmpeg."
set "music_ffmpeg_extract_error=Erreur lors de l'extraction de ffmpeg."
set "music_ffmpeg_folder_error=Dossier ffmpeg introuvable apres extraction."
set "music_youtube_detected=Lien YouTube detecte."
set "music_downloading=Telechargement et lecture"
set "music_download_error_msg=Erreur lors du telechargement."
set "music_playing=Lecture de"
set "music_save_yn=Enregistrer (O/N)"
set "music_save_path=Entrez le chemin de sauvegarde (ex: C:\Musique\)"
set "music_save_filename=Entrez le nom du fichier (sans extension)"
set "music_save_error=Erreur lors de la sauvegarde du fichier."
set "music_saved_at=Fichier sauvegarde a"
set "music_spotify_detected=Lien Spotify detecte."
set "music_downloading_spotdl=Telechargement avec spotdl"
exit /b

:detect_os_language
set "detected_language=FR"
for /f "tokens=2 delims==" %%A in ('wmic os get locale ^| findstr .'') do (
    set "os_locale=%%A"
)
set "os_locale=!os_locale: =!"

if "!os_locale!"=="40C" set "detected_language=FR"
if "!os_locale!"=="C0C" set "detected_language=FR"
if "!os_locale!"=="80C" set "detected_language=FR"
if "!os_locale!"=="100C" set "detected_language=FR"
if "!os_locale!"=="140C" set "detected_language=FR"
if "!os_locale!"=="180C" set "detected_language=FR"
if "!os_locale!"=="1C0C" set "detected_language=FR"

if "!os_locale!"=="409" set "detected_language=EN"
if "!os_locale!"=="809" set "detected_language=EN"
if "!os_locale!"=="C09" set "detected_language=EN"
if "!os_locale!"=="1009" set "detected_language=EN"
if "!os_locale!"=="1409" set "detected_language=EN"
if "!os_locale!"=="1809" set "detected_language=EN"
if "!os_locale!"=="1C09" set "detected_language=EN"
if "!os_locale!"=="2009" set "detected_language=EN"
if "!os_locale!"=="2409" set "detected_language=EN"
if "!os_locale!"=="2809" set "detected_language=EN"
if "!os_locale!"=="2C09" set "detected_language=EN"
if "!os_locale!"=="3009" set "detected_language=EN"
if "!os_locale!"=="3409" set "detected_language=EN"

if "!os_locale!"=="C0A" set "detected_language=ES"
if "!os_locale!"=="40A" set "detected_language=ES"
if "!os_locale!"=="80A" set "detected_language=ES"
if "!os_locale!"=="100A" set "detected_language=ES"
if "!os_locale!"=="140A" set "detected_language=ES"
if "!os_locale!"=="180A" set "detected_language=ES"
if "!os_locale!"=="1C0A" set "detected_language=ES"
if "!os_locale!"=="200A" set "detected_language=ES"

if "!os_locale!"=="407" set "detected_language=DE"
if "!os_locale!"=="807" set "detected_language=DE"
if "!os_locale!"=="C07" set "detected_language=DE"
if "!os_locale!"=="1007" set "detected_language=DE"
if "!os_locale!"=="1407" set "detected_language=DE"

if "!os_locale!"=="410" set "detected_language=IT"
if "!os_locale!"=="810" set "detected_language=IT"

if "!os_locale!"=="416" set "detected_language=PT"
if "!os_locale!"=="816" set "detected_language=PT"

if "!os_locale!"=="419" set "detected_language=RU"
if "!os_locale!"=="819" set "detected_language=RU"

if "!os_locale!"=="411" set "detected_language=JA"

if "!os_locale!"=="404" set "detected_language=ZH"
if "!os_locale!"=="804" set "detected_language=ZH"
if "!os_locale!"=="C04" set "detected_language=ZH"

if "!os_locale!"=="413" set "detected_language=NL"
if "!os_locale!"=="813" set "detected_language=NL"

if "!os_locale!"=="415" set "detected_language=PL"

exit /b
