@echo off
title TelStore
setlocal enabledelayedexpansion
chcp 65001 >nul

if not exist "..\config\lang.txt" (
    if not exist "..\config" mkdir "..\config"
    call :detect_os_language
    echo language=!detected_language!>"..\config\lang.txt"
)

call :load_language

:MENU
cls
echo.
echo ===============================================
echo              !ts_title!
echo ===============================================
echo.
echo !ts_maintenance!
echo.
echo !ts_reason!
echo !ts_apology!
echo !ts_staying_tuned!
echo.
echo !ts_thank_you!
echo.
pause

exit /b

:load_language
set "lang=FR"
if exist "..\config\lang.txt" (
    for /f "tokens=2 delims==" %%A in ('type ..\config\lang.txt ^| findstr /i "^language"') do (
        set "lang=%%A"
    )
)
set "lang=!lang: =!"

if /i "!lang!"=="EN" goto :lang_EN
if /i "!lang!"=="ES" goto :lang_ES
if /i "!lang!"=="DE" goto :lang_DE
if /i "!lang!"=="IT" goto :lang_IT
if /i "!lang!"=="PT" goto :lang_PT
if /i "!lang!"=="RU" goto :lang_RU
if /i "!lang!"=="JA" goto :lang_JA
if /i "!lang!"=="ZH" goto :lang_ZH
if /i "!lang!"=="NL" goto :lang_NL
if /i "!lang!"=="PL" goto :lang_PL
goto :lang_FR

:lang_EN
set "ts_title=TelService STORE"
set "ts_maintenance=TelStore service interruption."
set "ts_reason=Due to the complexity of managing applications and updates, TelStore is temporarily suspended for a complete overhaul."
set "ts_apology=We apologize for the inconvenience and are actively working on a new version of TelStore that will offer a better user experience and more efficient application and update management."
set "ts_staying_tuned=Stay tuned for updates on TelStore's return."
set "ts_thank_you=Thank you for your understanding."
exit /b

:lang_ES
set "ts_title=Tienda TelService"
set "ts_maintenance=Interrupcion del servicio de TelStore."
set "ts_reason=Debido a la complejidad de la gestion de aplicaciones y actualizaciones, TelStore esta temporalmente suspendido para una refundicion completa."
set "ts_apology=Nos disculpamos por las molestias y estamos trabajando activamente en una nueva version de TelStore que ofrecera una mejor experiencia de usuario y una gestion mas eficiente de aplicaciones y actualizaciones."
set "ts_staying_tuned=Manténgase atento a las actualizaciones sobre el regreso de TelStore."
set "ts_thank_you=Gracias por su comprension."
exit /b

:lang_DE
set "ts_title=TelService STORE"
set "ts_maintenance=TelStore-Service-Unterbrechung."
set "ts_reason=Aufgrund der Komplexitat der Verwaltung von Anwendungen und Updates ist TelStore vorubergehend fur eine vollstandige Uberarbeitung unterbrochen."
set "ts_apology=Wir entschuldigen uns fur die Unannehmlichkeiten und arbeiten aktiv an einer neuen Version von TelStore, die ein besseres Benutzererlebnis und eine effizientere Verwaltung von Anwendungen und Updates bietet."
set "ts_staying_tuned=Bleiben Sie dran fur Updates zur Ruckkehr von TelStore."
set "ts_thank_you=Vielen Dank fur Ihr Verstandnis."
exit /b

:lang_IT
set "ts_title=TelService STORE"
set "ts_maintenance=Interruzione del servizio TelStore."
set "ts_reason=A causa della complessita della gestione delle applicazioni e degli aggiornamenti, TelStore e temporaneamente sospeso per una revisione completa."
set "ts_apology=Ci scusiamo per il disagio e stiamo attivamente lavorando su una nuova versione di TelStore che offrira un'esperienza utente migliore e una gestione piu efficiente delle applicazioni e degli aggiornamenti."
set "ts_staying_tuned=Rimani sintonizzato per gli aggiornamenti sul ritorno di TelStore."
set "ts_thank_you=Grazie per la tua comprensione."
exit /b

:lang_PT
set "ts_title=LOJA TelService"
set "ts_maintenance=Interrupcao do servico TelStore."
set "ts_reason=Devido a complexidade do gerenciamento de aplicacoes e atualizacoes, TelStore esta temporariamente suspenso para uma revisao completa."
set "ts_apology=Pedimos desculpas pelo inconveniente e estamos trabalhando ativamente em uma nova versao do TelStore que oferecera uma melhor experiencia do usuario e um gerenciamento mais eficiente de aplicacoes e atualizacoes."
set "ts_staying_tuned=Fique atento para atualizacoes sobre o retorno da TelStore."
set "ts_thank_you=Obrigado por sua compreensao."
exit /b

:lang_RU
set "ts_title=TelService STORE"
set "ts_maintenance=Preryvanie servisa TelStore."
set "ts_reason=Iz-za slozhnosti upravleniya prilozheniyami i obnovleniyami TelStore vremenno priostanovlen dlya polnoy pererabotki."
set "ts_apology=Izvinite za neuzdobstvo i my aktivno rabotayem nad novoy versiey TelStore, kotoraya predostavit luchshiy opyt polzovatelya i bolee effektivnoe upravlenie prilozheniami i obnovleniyami."
set "ts_staying_tuned=Sledte novostey o vozvrashchenii TelStore."
set "ts_thank_you=Spasibo za vase ponimaniye."
exit /b

:lang_JA
set "ts_title=TelService STORE"
set "ts_maintenance=TelStore saabisu kutan."
set "ts_reason=Aopuri to appudeto no kanri no fukuzatsusa yori, TelStore wa ichiji teishi sarete imasu kanzen na kaizo no tame."
set "ts_apology=Gomenasai gai o okeshi masu ga, yori yoi yuuza taiken to yori koritsu teki na aopuri to appudeto kanri wo teikyo suru TelStore no shin ban wo kahatsu chuu desu."
set "ts_staying_tuned=TelStore no gaeri ni tsuite no apudeto ni chui shite kudasai."
set "ts_thank_you=Gokenkai arigatou gozaimasu."
exit /b

:lang_ZH
set "ts_title=TelService STORE"
set "ts_maintenance=TelStore fuwu zhongduan."
set "ts_reason=You yu yingyong chengxu he genxin de guanli de fuza xing, TelStore lincai yinxiao zanting wanquan gaituozao."
set "ts_apology=Women zhepeiqian bu pian jiuzhu he jijun kaifa xin ban TelStore, jiangshanye dui yonghu ti gong geng liang hao de tiyan he geng you xiao de yingyong chengxu he genxin guanli."
set "ts_staying_tuned=Kuai yao geng xin TelStore hui gui xin xi."
set "ts_thank_you=Xie xie nin de li jie."
exit /b

:lang_NL
set "ts_title=TelService WINKEL"
set "ts_maintenance=TelStore service onderbreking."
set "ts_reason=Vanwege de complexiteit van het beheer van applicaties en updates is TelStore tijdelijk opgeschort voor een complete herziening."
set "ts_apology=We verontschuldigen ons voor het ongemak en werken actief aan een nieuwe versie van TelStore die een beter gebruikerservaring en effectiever applicatie- en updatebeheer biedt."
set "ts_staying_tuned=Volg de updates over de terugkeer van TelStore."
set "ts_thank_you=Dank u voor uw geduld."
exit /b

:lang_PL
set "ts_title=TelService SKLEP"
set "ts_maintenance=Przerwanie uslugi TelStore."
set "ts_reason=Ze wzgledu na zlozonosc zarzadzania aplikacjami i aktualizacjami, TelStore jest tymczasowo wstrzymany w celu pelnej przebudowy."
set "ts_apology=Przepraszamy za niedogodnosci i aktywnie pracujemy nad nowa wersja TelStore, ktora zapewni lepsze doswiadczenie uzytkownika i wydajniejsze zarzadzanie aplikacjami i aktualizacjami."
set "ts_staying_tuned=Sledz aktualizacje dotyczace powrotu TelStore."
set "ts_thank_you=Dzieki za twoje zrozumienie."
exit /b

:lang_FR
set "ts_title=TelService STORE"
set "ts_maintenance=Interruption du service de TelStore."
set "ts_reason=Du a la complication de la gestion des applications et des mises a jour, TelStore est temporairement suspendu pour une refonte complete."
set "ts_apology=Nous nous excusons pour la gene occasionnee et travaillons activement a une nouvelle version de TelStore qui offrira une meilleure experience utilisateur et une gestion plus efficace des applications et des mises a jour."
set "ts_staying_tuned=Restez a l'ecoute pour les mises a jour sur le retour de TelStore."
set "ts_thank_you=Merci de votre comprehension."
exit /b

:detect_os_language
set "detected_language=FR"
for /f "tokens=2 delims==" %%A in ('wmic os get locale ^| findstr .'') do (
    set "os_locale=%%A"
)
set "os_locale=!os_locale: =!"

if "!os_locale!"=="40C" set "detected_language=FR"
if "!os_locale!"=="C0C" set "detected_language=FR"
if "!os_locale!"=="80C" set "detected_language=FR"
if "!os_locale!"=="100C" set "detected_language=FR"
if "!os_locale!"=="140C" set "detected_language=FR"
if "!os_locale!"=="180C" set "detected_language=FR"
if "!os_locale!"=="1C0C" set "detected_language=FR"

if "!os_locale!"=="409" set "detected_language=EN"
if "!os_locale!"=="809" set "detected_language=EN"
if "!os_locale!"=="C09" set "detected_language=EN"
if "!os_locale!"=="1009" set "detected_language=EN"
if "!os_locale!"=="1409" set "detected_language=EN"
if "!os_locale!"=="1809" set "detected_language=EN"
if "!os_locale!"=="1C09" set "detected_language=EN"
if "!os_locale!"=="2009" set "detected_language=EN"
if "!os_locale!"=="2409" set "detected_language=EN"
if "!os_locale!"=="2809" set "detected_language=EN"
if "!os_locale!"=="2C09" set "detected_language=EN"
if "!os_locale!"=="3009" set "detected_language=EN"
if "!os_locale!"=="3409" set "detected_language=EN"

if "!os_locale!"=="C0A" set "detected_language=ES"
if "!os_locale!"=="40A" set "detected_language=ES"
if "!os_locale!"=="80A" set "detected_language=ES"
if "!os_locale!"=="100A" set "detected_language=ES"
if "!os_locale!"=="140A" set "detected_language=ES"
if "!os_locale!"=="180A" set "detected_language=ES"
if "!os_locale!"=="1C0A" set "detected_language=ES"
if "!os_locale!"=="200A" set "detected_language=ES"

if "!os_locale!"=="407" set "detected_language=DE"
if "!os_locale!"=="807" set "detected_language=DE"
if "!os_locale!"=="C07" set "detected_language=DE"
if "!os_locale!"=="1007" set "detected_language=DE"
if "!os_locale!"=="1407" set "detected_language=DE"

if "!os_locale!"=="410" set "detected_language=IT"
if "!os_locale!"=="810" set "detected_language=IT"

if "!os_locale!"=="416" set "detected_language=PT"
if "!os_locale!"=="816" set "detected_language=PT"

if "!os_locale!"=="419" set "detected_language=RU"
if "!os_locale!"=="819" set "detected_language=RU"

if "!os_locale!"=="411" set "detected_language=JA"

if "!os_locale!"=="404" set "detected_language=ZH"
if "!os_locale!"=="804" set "detected_language=ZH"
if "!os_locale!"=="C04" set "detected_language=ZH"

if "!os_locale!"=="413" set "detected_language=NL"
if "!os_locale!"=="813" set "detected_language=NL"

if "!os_locale!"=="415" set "detected_language=PL"

exit /b