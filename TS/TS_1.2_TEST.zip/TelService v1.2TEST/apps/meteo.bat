@echo off
title Meteo
setlocal enabledelayedexpansion
chcp 65001 >nul

REM Configuration
set "CONFIG_FILE=%~dp0meteo_config.txt"

REM Create parent config if needed
if not exist "..\config\lang.txt" (
    if not exist "..\config" mkdir "..\config"
    call :detect_os_language
    echo language=!detected_language!>"..\config\lang.txt"
)

REM Charger la langue
call :load_language

REM Charger la ville mémorisée
set "CITY=Paris"
if exist "%CONFIG_FILE%" (
    for /f "delims=" %%a in ('type "%CONFIG_FILE%"') do (
        set "CITY=%%a"
    )
)

:MENU
cls
echo.
echo =============================================
echo           !meteo_title!
echo =============================================
echo.
echo !meteo_current_city!: %CITY%
echo.
echo 1. !meteo_view_weather! %CITY%
echo 2. !meteo_change_city!
echo 3. !meteo_quit!
echo.
set /p "CHOICE=!meteo_choose_option! (1-3): "

if "%CHOICE%"=="1" goto METEO
if "%CHOICE%"=="2" goto CHANGECITY
if "%CHOICE%"=="3" goto END
echo.
echo !meteo_invalid_option!
timeout /t 2 >nul
goto MENU

:CHANGECITY
cls
echo.
echo ====================================
echo           !meteo_change_city_title!
echo ====================================
echo.
echo !meteo_popular_cities!: Paris, Lyon, Marseille, Toulouse, Nice, Bordeaux
echo.
set /p "NEWCITY=!meteo_enter_city!: "

if "%NEWCITY%"=="" (
    echo Nom vide, retour au menu...
    timeout /t 2 >nul
    goto MENU
)

REM Vérifier que la ville existe
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0meteo_check.ps1" "%NEWCITY%"

if !errorlevel! equ 0 (
    echo %NEWCITY%> "%CONFIG_FILE%"
    set "CITY=%NEWCITY%"
    echo.
    echo Ville sauvegardee!
    timeout /t 2 >nul
    goto MENU
) else (
    echo.
    echo Appuyez sur une touche...
    pause >nul
    goto CHANGECITY
)

:METEO
cls
echo.
echo =============================================
echo           !meteo_title!
echo =============================================
echo.
echo !meteo_retrieving_data!: %CITY%
echo.

REM Appel API via PowerShell
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0meteo_get.ps1" "%CITY%"

echo.
echo ===============================================
echo !meteo_press_key_continue!
pause >nul
goto MENU

:END
echo.
echo !meteo_goodbye!
echo.

:load_language
set "lang=FR"
if exist "..\config\lang.txt" (
    for /f "tokens=2 delims==" %%A in ('type ..\config\lang.txt ^| findstr /i "^language"') do (
        set "lang=%%A"
    )
)
set "lang=!lang: =!"

if /i "!lang!"=="EN" goto :lang_EN
if /i "!lang!"=="ES" goto :lang_ES
if /i "!lang!"=="DE" goto :lang_DE
if /i "!lang!"=="IT" goto :lang_IT
if /i "!lang!"=="PT" goto :lang_PT
if /i "!lang!"=="RU" goto :lang_RU
if /i "!lang!"=="JA" goto :lang_JA
if /i "!lang!"=="ZH" goto :lang_ZH
if /i "!lang!"=="NL" goto :lang_NL
if /i "!lang!"=="PL" goto :lang_PL
goto :lang_FR

:lang_EN
set "meteo_title=Online Weather System"
set "meteo_current_city=Current city"
set "meteo_view_weather=View weather for"
set "meteo_change_city=Change city"
set "meteo_quit=Quit"
set "meteo_choose_option=Choose an option"
set "meteo_invalid_option=Invalid option!"
set "meteo_change_city_title=Change City"
set "meteo_popular_cities=Popular cities"
set "meteo_enter_city=Enter city name"
set "meteo_retrieving_data=Retrieving weather data for"
set "meteo_press_key_continue=Press a key to return to menu..."
set "meteo_goodbye=Goodbye!"
exit /b

:lang_ES
set "meteo_title=Sistema de Meteorologia en Linea"
set "meteo_current_city=Ciudad actual"
set "meteo_view_weather=Ver el tiempo para"
set "meteo_change_city=Cambiar ciudad"
set "meteo_quit=Salir"
set "meteo_choose_option=Elija una opcion"
set "meteo_invalid_option=Opcion invalida!"
set "meteo_change_city_title=Cambiar Ciudad"
set "meteo_popular_cities=Ciudades populares"
set "meteo_enter_city=Ingrese el nombre de la ciudad"
set "meteo_retrieving_data=Recuperando datos meteorologicos para"
set "meteo_press_key_continue=Presione una tecla para volver al menu..."
set "meteo_goodbye=Adios!"
exit /b

:lang_DE
set "meteo_title=Online-Wettersystem"
set "meteo_current_city=Aktuelle Stadt"
set "meteo_view_weather=Wetter anzeigen fur"
set "meteo_change_city=Stadt andern"
set "meteo_quit=Beenden"
set "meteo_choose_option=Wahlen Sie eine Option"
set "meteo_invalid_option=Ungultige Option!"
set "meteo_change_city_title=Stadt andern"
set "meteo_popular_cities=Beliebte Stadte"
set "meteo_enter_city=Stadtnamen eingeben"
set "meteo_retrieving_data=Wetterdaten abrufen fur"
set "meteo_press_key_continue=Drucken Sie eine Taste, um zum Menu zuruckzukehren..."
set "meteo_goodbye=Auf Wiedersehen!"
exit /b

:lang_IT
set "meteo_title=Sistema Meteorologia Online"
set "meteo_current_city=Citta attuale"
set "meteo_view_weather=Visualizza meteo per"
set "meteo_change_city=Cambiar citta"
set "meteo_quit=Esci"
set "meteo_choose_option=Seleziona un'opzione"
set "meteo_invalid_option=Opzione non valida!"
set "meteo_change_city_title=Cambia Citta"
set "meteo_popular_cities=Citta popolari"
set "meteo_enter_city=Inserisci nome citta"
set "meteo_retrieving_data=Recupero dati meteorologici per"
set "meteo_press_key_continue=Premi un tasto per tornare al menu..."
set "meteo_goodbye=Arrivederci!"
exit /b

:lang_PT
set "meteo_title=Sistema de Meteorologia Online"
set "meteo_current_city=Cidade atual"
set "meteo_view_weather=Ver tempo para"
set "meteo_change_city=Mudar cidade"
set "meteo_quit=Sair"
set "meteo_choose_option=Selecione uma opcao"
set "meteo_invalid_option=Opcao invalida!"
set "meteo_change_city_title=Mudar Cidade"
set "meteo_popular_cities=Cidades populares"
set "meteo_enter_city=Digite o nome da cidade"
set "meteo_retrieving_data=Recuperando dados meteorologicos para"
set "meteo_press_key_continue=Pressione uma tecla para voltar ao menu..."
set "meteo_goodbye=Ate logo!"
exit /b

:lang_RU
set "meteo_title=Sistema Meteorologii Online"
set "meteo_current_city=Tekushchiy gorod"
set "meteo_view_weather=Pokazat pogodu dlya"
set "meteo_change_city=Izmenit gorod"
set "meteo_quit=Vykhod"
set "meteo_choose_option=Vyberite variant"
set "meteo_invalid_option=Nepravilnyy variant!"
set "meteo_change_city_title=Izmenit Gorod"
set "meteo_popular_cities=Populyarnyye goroda"
set "meteo_enter_city=Vvedite nazvanie goroda"
set "meteo_retrieving_data=Polucheniye meteorologicheskikh dannyh dlya"
set "meteo_press_key_continue=Spayte klavishu dlya vozvrata v menyu..."
set "meteo_goodbye=Do svidaniya!"
exit /b

:lang_JA
set "meteo_title=Onrain Kikou Sisutemu"
set "meteo_current_city=Genzai Toshi"
set "meteo_view_weather=Kikou wo miru"
set "meteo_change_city=Toshi wo kaeru"
set "meteo_quit=Shutsuryoku"
set "meteo_choose_option=Opushon wo sentaku"
set "meteo_invalid_option=Fukatekina opushon!"
set "meteo_change_city_title=Toshi o Kaeru"
set "meteo_popular_cities=Ninki toshi"
set "meteo_enter_city=Toshi mei wo nyuryoku"
set "meteo_retrieving_data=Kikou deta o shutoku"
set "meteo_press_key_continue=Suupatsu wo shite menu ni modorimasu..."
set "meteo_goodbye=Sayounara!"
exit /b

:lang_ZH
set "meteo_title=Zaixian Qixiang Xitong"
set "meteo_current_city=Dangqian Chengshi"
set "meteo_view_weather=Cha kan tian qi"
set "meteo_change_city=Gaibian chengshi"
set "meteo_quit=Tuichu"
set "meteo_choose_option=Xuanze xuanxiang"
set "meteo_invalid_option=Wufa xuanxiang!"
set "meteo_change_city_title=Gaibian Chengshi"
set "meteo_popular_cities=Liuxing chengshi"
set "meteo_enter_city=Shuru chengshi ming"
set "meteo_retrieving_data=Huoqu qixiang shuju"
set "meteo_press_key_continue=Yi an ren yi ge jian hui dao caidan..."
set "meteo_goodbye=Zaijian!"
exit /b

:lang_NL
set "meteo_title=Online Meteorologie-systeem"
set "meteo_current_city=Huidge stad"
set "meteo_view_weather=Weer weergeven voor"
set "meteo_change_city=Plaats wijzigen"
set "meteo_quit=Afsluiten"
set "meteo_choose_option=Selecteer een optie"
set "meteo_invalid_option=Ongeldige optie!"
set "meteo_change_city_title=Plaats Wijzigen"
set "meteo_popular_cities=Populaire steden"
set "meteo_enter_city=Voer stadsnaam in"
set "meteo_retrieving_data=Meteorologische gegevens ophalen voor"
set "meteo_press_key_continue=Druk op een toets om naar menu te gaan..."
set "meteo_goodbye=Tot ziens!"
exit /b

:lang_PL
set "meteo_title=Systemn Meteorologii online"
set "meteo_current_city=Aktualne Miasto"
set "meteo_view_weather=Poka z pogodes dla"
set "meteo_change_city=Zmien miasto"
set "meteo_quit=Wyjscie"
set "meteo_choose_option=Wybierz opcje"
set "meteo_invalid_option=Nieprawidlowa opcja!"
set "meteo_change_city_title=Zmien Miasto"
set "meteo_popular_cities=Popularne miasta"
set "meteo_enter_city=Wpisz nazwe miasta"
set "meteo_retrieving_data=Pobieranie danych meteorologicznych dla"
set "meteo_press_key_continue=Nacisnij klawisz aby powrocic do menu..."
set "meteo_goodbye=Do widzenia!"
exit /b
set "meteo_title=Systeme de Meteo en Ligne"
set "meteo_current_city=Ville actuelle"
set "meteo_view_weather=Voir la meteo pour"
set "meteo_change_city=Changer de ville"
set "meteo_quit=Quitter"
set "meteo_choose_option=Choisissez une option"
set "meteo_invalid_option=Option invalide!"
set "meteo_change_city_title=Changer de Ville"
set "meteo_popular_cities=Villes populaires"
set "meteo_enter_city=Entrez le nom de la ville"
set "meteo_retrieving_data=Recuperation des donnees meteo pour"
set "meteo_press_key_continue=Appuyez sur une touche pour revenir au menu..."
set "meteo_goodbye=Au revoir!"
exit /b

:detect_os_language
set "detected_language=FR"
for /f "tokens=2 delims==" %%A in ('wmic os get locale ^| findstr .'') do (
    set "os_locale=%%A"
)
set "os_locale=!os_locale: =!"

if "!os_locale!"=="40C" set "detected_language=FR"
if "!os_locale!"=="C0C" set "detected_language=FR"
if "!os_locale!"=="80C" set "detected_language=FR"
if "!os_locale!"=="100C" set "detected_language=FR"
if "!os_locale!"=="140C" set "detected_language=FR"
if "!os_locale!"=="180C" set "detected_language=FR"
if "!os_locale!"=="1C0C" set "detected_language=FR"

if "!os_locale!"=="409" set "detected_language=EN"
if "!os_locale!"=="809" set "detected_language=EN"
if "!os_locale!"=="C09" set "detected_language=EN"
if "!os_locale!"=="1009" set "detected_language=EN"
if "!os_locale!"=="1409" set "detected_language=EN"
if "!os_locale!"=="1809" set "detected_language=EN"
if "!os_locale!"=="1C09" set "detected_language=EN"
if "!os_locale!"=="2009" set "detected_language=EN"
if "!os_locale!"=="2409" set "detected_language=EN"
if "!os_locale!"=="2809" set "detected_language=EN"
if "!os_locale!"=="2C09" set "detected_language=EN"
if "!os_locale!"=="3009" set "detected_language=EN"
if "!os_locale!"=="3409" set "detected_language=EN"

if "!os_locale!"=="C0A" set "detected_language=ES"
if "!os_locale!"=="40A" set "detected_language=ES"
if "!os_locale!"=="80A" set "detected_language=ES"
if "!os_locale!"=="100A" set "detected_language=ES"
if "!os_locale!"=="140A" set "detected_language=ES"
if "!os_locale!"=="180A" set "detected_language=ES"
if "!os_locale!"=="1C0A" set "detected_language=ES"
if "!os_locale!"=="200A" set "detected_language=ES"

if "!os_locale!"=="407" set "detected_language=DE"
if "!os_locale!"=="807" set "detected_language=DE"
if "!os_locale!"=="C07" set "detected_language=DE"
if "!os_locale!"=="1007" set "detected_language=DE"
if "!os_locale!"=="1407" set "detected_language=DE"

if "!os_locale!"=="410" set "detected_language=IT"
if "!os_locale!"=="810" set "detected_language=IT"

if "!os_locale!"=="416" set "detected_language=PT"
if "!os_locale!"=="816" set "detected_language=PT"

if "!os_locale!"=="419" set "detected_language=RU"
if "!os_locale!"=="819" set "detected_language=RU"

if "!os_locale!"=="411" set "detected_language=JA"

if "!os_locale!"=="404" set "detected_language=ZH"
if "!os_locale!"=="804" set "detected_language=ZH"
if "!os_locale!"=="C04" set "detected_language=ZH"

if "!os_locale!"=="413" set "detected_language=NL"
if "!os_locale!"=="813" set "detected_language=NL"

if "!os_locale!"=="415" set "detected_language=PL"

exit /b
