@echo off
setlocal enabledelayedexpansion
title TelService Menu
cd /d "%~dp0"
chcp 65001 >nul

:init
if not exist config\ (
    mkdir config
    echo 1>config\updates.txt
    echo 07>config\color.txt
    call :detect_os_language
    echo language=!detected_language!>config\lang.txt
) else (
    if not exist config\updates.txt echo 1>config\updates.txt
    if not exist config\color.txt echo 07>config\color.txt
    if not exist config\lang.txt (
        call :detect_os_language
        echo language=!detected_language!>config\lang.txt
    )
)
call :load_color
call :load_language

:menu
cls
echo ==================================================
echo              !menu_title!
echo ==================================================
echo.
echo !menu_apps!:
echo.
echo 1. !app_1!
echo 2. !app_2!
echo 3. !app_3!
echo 4. !app_4!
echo 5. !app_5!
echo 6. !app_6!
echo 7. !app_7!
echo.
echo 8. !menu_settings!
echo 9. !menu_update!
echo 0. !menu_exit!
echo.
set /p choice="!menu_choice!: "

if "%choice%"=="1" (
    if exist "apps\freeVM.bat" (
        call "apps\freeVM.bat"
    ) else (
        echo !error_app_not_installed! (!app_1!)
        pause
        goto menu
    )
    goto menu
) else if "%choice%"=="2" (
    if exist "apps\myAIRBENZ.bat" (
        call "apps\myAIRBENZ.bat"
    ) else (
        echo !error_app_not_installed! (!app_2!)
        pause
        goto menu
    )
    goto menu
) else if "%choice%"=="3" (
    if exist "apps\meteo.bat" (
        call "apps\meteo.bat"
    ) else (
        echo !error_app_not_installed! (!app_3!)
        pause
        goto menu
    )
    goto menu
) else if "%choice%"=="4" (
    if exist "apps\musique.bat" (
        call "apps\musique.bat"
    ) else (
        echo !error_app_not_installed! (!app_4!)
        pause
        goto menu
    )
    goto menu
) else if "%choice%"=="5" (
    call "apps\telstore.bat"
    goto menu
)else if "%choice%"=="6" (
    if exist "apps\ASCIImation.bat" (
        call "apps\ASCIImation.bat"
    ) else (
        echo !error_app_not_installed! (!app_6!)
        pause
        goto menu
    )
    goto menu
) else if "%choice%"=="7" (
    if exist "apps\jeux.bat" (
        call "apps\jeux.bat"
    ) else (
        echo !error_app_not_installed! (!app_7!)
        pause
        goto menu
    )
    goto menu
) else if "%choice%"=="8" (
    call settings.bat
    call :load_color
    call :load_language
    goto menu
) else if "%choice%"=="9" (
    call TSManager\TSManager.bat update
    goto menu
) else if "%choice%"=="0" (
    echo !msg_goodbye!
    exit /b
) else (
    echo !error_invalid_choice!
    pause
    goto menu
)

:load_color
set "ui_color=07"
if exist "config\color.txt" set /p ui_color=<config\color.txt
set "ui_color=!ui_color: =!"
if "!ui_color!"=="" set "ui_color=07"
if "!ui_color:~1,1!"=="" set "ui_color=0!ui_color!"
echo(!ui_color!| findstr /r /i "^[0-9A-F][0-9A-F]$" >nul || set "ui_color=07"
if /i "!ui_color:~0,1!"=="!ui_color:~1,1!" set "ui_color=07"
color !ui_color! >nul 2>nul
exit /b

:load_language
set "lang=FR"
if exist "config\lang.txt" (
    for /f "tokens=2 delims==" %%A in ('type config\lang.txt ^| findstr /i "^language"') do (
        set "lang=%%A"
    )
)
set "lang=!lang: =!"

if /i "!lang!"=="EN" goto :lang_EN
if /i "!lang!"=="ES" goto :lang_ES
if /i "!lang!"=="DE" goto :lang_DE
if /i "!lang!"=="IT" goto :lang_IT
if /i "!lang!"=="PT" goto :lang_PT
if /i "!lang!"=="RU" goto :lang_RU
if /i "!lang!"=="JA" goto :lang_JA
if /i "!lang!"=="ZH" goto :lang_ZH
if /i "!lang!"=="NL" goto :lang_NL
if /i "!lang!"=="PL" goto :lang_PL
goto :lang_FR

:lang_EN
set "menu_title=TelService Menu"
set "menu_apps=Applications"
set "app_1=LSE FreeVM"
set "app_2=myAIRBENZ"
set "app_3=Meteorology"
set "app_4=Music"
set "app_5=TelStore"
set "app_6=ASCIImation"
set "app_7=Games"
set "menu_settings=Settings"
set "menu_update=Update TelService"
set "menu_exit=Exit"
set "menu_choice=Select an option (0/9)"
set "error_app_not_installed=is not installed. Please install it via TelStore."
set "msg_goodbye=Thank you for using TelService. Goodbye!"
set "error_invalid_choice=Invalid choice. Please try again."
exit /b

:lang_ES
set "menu_title=Menu TelService"
set "menu_apps=Aplicaciones"
set "app_1=LSE FreeVM"
set "app_2=myAIRBENZ"
set "app_3=Meteorologia"
set "app_4=Musica"
set "app_5=TelStore"
set "app_6=ASCIImation"
set "app_7=Juegos"
set "menu_settings=Configuracion"
set "menu_update=Actualizar TelService"
set "menu_exit=Salir"
set "menu_choice=Seleccione una opcion (0/9)"
set "error_app_not_installed=no esta instalada. Instalela a traves de TelStore."
set "msg_goodbye=Gracias por usar TelService. Adios!"
set "error_invalid_choice=Opcion invalida. Intente de nuevo."
exit /b

:lang_DE
set "menu_title=TelService Menue"
set "menu_apps=Anwendungen"
set "app_1=LSE FreeVM"
set "app_2=myAIRBENZ"
set "app_3=Meteorologie"
set "app_4=Musik"
set "app_5=TelStore"
set "app_6=ASCIImation"
set "app_7=Spiele"
set "menu_settings=Einstellungen"
set "menu_update=TelService aktualisieren"
set "menu_exit=Beenden"
set "menu_choice=Wahlen Sie eine Option (0/9)"
set "error_app_not_installed=ist nicht installiert. Bitte installieren Sie es uber TelStore."
set "msg_goodbye=Danke, dass Sie TelService verwendet haben. Auf Wiedersehen!"
set "error_invalid_choice=Ungultige Wahl. Bitte versuchen Sie es erneut."
exit /b

:lang_IT
set "menu_title=Menu TelService"
set "menu_apps=Applicazioni"
set "app_1=LSE FreeVM"
set "app_2=myAIRBENZ"
set "app_3=Meteorologia"
set "app_4=Musica"
set "app_5=TelStore"
set "app_6=ASCIImation"
set "app_7=Giochi"
set "menu_settings=Impostazioni"
set "menu_update=Aggiornamento TelService"
set "menu_exit=Esci"
set "menu_choice=Seleziona un'opzione (0/9)"
set "error_app_not_installed=non e installato. Installalo tramite TelStore."
set "msg_goodbye=Grazie per aver utilizzato TelService. Arrivederci!"
set "error_invalid_choice=Scelta non valida. Riprova."
exit /b

:lang_PT
set "menu_title=Menu TelService"
set "menu_apps=Aplicacoes"
set "app_1=LSE FreeVM"
set "app_2=myAIRBENZ"
set "app_3=Meteorologia"
set "app_4=Musica"
set "app_5=TelStore"
set "app_6=ASCIImation"
set "app_7=Jogos"
set "menu_settings=Configuracoes"
set "menu_update=Atualizacao TelService"
set "menu_exit=Sair"
set "menu_choice=Selecione uma opcao (0/9)"
set "error_app_not_installed=nao esta instalado. Instale via TelStore."
set "msg_goodbye=Obrigado por usar TelService. Ate logo!"
set "error_invalid_choice=Opcao invalida. Tente novamente."
exit /b

:lang_RU
set "menu_title=Menu TelService"
set "menu_apps=Prilozhenia"
set "app_1=LSE FreeVM"
set "app_2=myAIRBENZ"
set "app_3=Meteorologiya"
set "app_4=Muzyka"
set "app_5=TelStore"
set "app_6=ASCIImation"
set "app_7=Igry"
set "menu_settings=Nastroyki"
set "menu_update=Obnovlenie TelService"
set "menu_exit=Vykhod"
set "menu_choice=Vyberite variant (0/9)"
set "error_app_not_installed=ne ustanovlen. Ustanovite cherez TelStore."
set "msg_goodbye=Spasibo za ispolzovanie TelService. Do svidaniya!"
set "error_invalid_choice=Nepravilnyy vyboр. Poprobuite snova."
exit /b

:lang_JA
set "menu_title=TelService Menu"
set "menu_apps=Applications"
set "app_1=LSE FreeVM"
set "app_2=myAIRBENZ"
set "app_3=Kikou"
set "app_4=Ongaku"
set "app_5=TelStore"
set "app_6=ASCIImation"
set "app_7=Geemu"
set "menu_settings=Settei"
set "menu_update=TelService Koushin"
set "menu_exit=Shuuryou"
set "menu_choice=Sentaku shite kudasai (0/9)"
set "error_app_not_installed=wa insutooru sarete inai. TelStore kara insutoroo shite kudasai."
set "msg_goodbye=TelService wo goribiyou arigatou gozaimash. Sayounara!"
set "error_invalid_choice=Fukatekina sentaku. Mou ichido yatte mite kudasai."
exit /b

:lang_ZH
set "menu_title=TelService Menu"
set "menu_apps=Applications"
set "app_1=LSE FreeVM"
set "app_2=myAIRBENZ"
set "app_3=Qixiang"
set "app_4=Yinyue"
set "app_5=TelStore"
set "app_6=ASCIImation"
set "app_7=Youxi"
set "menu_settings=Shezhi"
set "menu_update=TelService Gengxin"
set "menu_exit=Tuichu"
set "menu_choice=Xuanze yige xuanxiang (0/9)"
set "error_app_not_installed=wei anzhuang. Qing tonguo TelStore anzhuang."
set "msg_goodbye=Ganbai shiyon TelService. Zaijian!"
set "error_invalid_choice=Xuanxiang wufa. Zaishi che shishi."
exit /b

:lang_NL
set "menu_title=TelService Menu"
set "menu_apps=Applicaties"
set "app_1=LSE FreeVM"
set "app_2=myAIRBENZ"
set "app_3=Meteorologie"
set "app_4=Muziek"
set "app_5=TelStore"
set "app_6=ASCIImation"
set "app_7=Spellen"
set "menu_settings=Instellingen"
set "menu_update=TelService Bijwerken"
set "menu_exit=Afsluiten"
set "menu_choice=Kies een optie (0/9)"
set "error_app_not_installed=is niet geinstralleerd. Installeer via TelStore."
set "msg_goodbye=Dank je voor het gebruik van TelService. Tot ziens!"
set "error_invalid_choice=Ongeldige keuze. Probeer opnieuw."
exit /b

:lang_PL
set "menu_title=Menu TelService"
set "menu_apps=Aplikacje"
set "app_1=LSE FreeVM"
set "app_2=myAIRBENZ"
set "app_3=Meteorologia"
set "app_4=Muzyka"
set "app_5=TelStore"
set "app_6=ASCIImation"
set "app_7=Gry"
set "menu_settings=Ustawienia"
set "menu_update=Aktualizacja TelService"
set "menu_exit=Wyjdz"
set "menu_choice=Wybierz opcje (0/9)"
set "error_app_not_installed=nie jest zainstalowana. Zainstaluj via TelStore."
set "msg_goodbye=Dzieki za uzycie TelService. Do widzenia!"
set "error_invalid_choice=Nieprawidiowa opcja. Sprobuj ponownie."
exit /b

:lang_FR
set "menu_title=TelService Menu"
set "menu_apps=Applications"
set "app_1=LSE FreeVM"
set "app_2=myAIRBENZ"
set "app_3=Meteorologie"
set "app_4=Musique"
set "app_5=TelStore"
set "app_6=ASCIImation"
set "app_7=Jeux"
set "menu_settings=Parametres"
set "menu_update=Mise a jour de TelService"
set "menu_exit=Quitter"
set "menu_choice=Selectionnez une option (0/9)"
set "error_app_not_installed=n'est pas installe. Veuillez l'installer via TelStore."
set "msg_goodbye=Merci d'avoir utilise TelService. Au revoir!"
set "error_invalid_choice=Choix invalide. Veuillez reessayer."
exit /b

:detect_os_language
set "detected_language=FR"
for /f "tokens=2 delims==" %%A in ('wmic os get locale ^| findstr .'') do (
    set "os_locale=%%A"
)
set "os_locale=!os_locale: =!"

if "!os_locale!"=="40C" set "detected_language=FR"
if "!os_locale!"=="C0C" set "detected_language=FR"
if "!os_locale!"=="80C" set "detected_language=FR"
if "!os_locale!"=="100C" set "detected_language=FR"
if "!os_locale!"=="140C" set "detected_language=FR"
if "!os_locale!"=="180C" set "detected_language=FR"
if "!os_locale!"=="1C0C" set "detected_language=FR"

if "!os_locale!"=="409" set "detected_language=EN"
if "!os_locale!"=="809" set "detected_language=EN"
if "!os_locale!"=="C09" set "detected_language=EN"
if "!os_locale!"=="1009" set "detected_language=EN"
if "!os_locale!"=="1409" set "detected_language=EN"
if "!os_locale!"=="1809" set "detected_language=EN"
if "!os_locale!"=="1C09" set "detected_language=EN"
if "!os_locale!"=="2009" set "detected_language=EN"
if "!os_locale!"=="2409" set "detected_language=EN"
if "!os_locale!"=="2809" set "detected_language=EN"
if "!os_locale!"=="2C09" set "detected_language=EN"
if "!os_locale!"=="3009" set "detected_language=EN"
if "!os_locale!"=="3409" set "detected_language=EN"

if "!os_locale!"=="C0A" set "detected_language=ES"
if "!os_locale!"=="40A" set "detected_language=ES"
if "!os_locale!"=="80A" set "detected_language=ES"
if "!os_locale!"=="100A" set "detected_language=ES"
if "!os_locale!"=="140A" set "detected_language=ES"
if "!os_locale!"=="180A" set "detected_language=ES"
if "!os_locale!"=="1C0A" set "detected_language=ES"
if "!os_locale!"=="200A" set "detected_language=ES"

if "!os_locale!"=="407" set "detected_language=DE"
if "!os_locale!"=="807" set "detected_language=DE"
if "!os_locale!"=="C07" set "detected_language=DE"
if "!os_locale!"=="1007" set "detected_language=DE"
if "!os_locale!"=="1407" set "detected_language=DE"

if "!os_locale!"=="410" set "detected_language=IT"
if "!os_locale!"=="810" set "detected_language=IT"

if "!os_locale!"=="416" set "detected_language=PT"
if "!os_locale!"=="816" set "detected_language=PT"

if "!os_locale!"=="419" set "detected_language=RU"
if "!os_locale!"=="819" set "detected_language=RU"

if "!os_locale!"=="411" set "detected_language=JA"

if "!os_locale!"=="404" set "detected_language=ZH"
if "!os_locale!"=="804" set "detected_language=ZH"
if "!os_locale!"=="C04" set "detected_language=ZH"

if "!os_locale!"=="413" set "detected_language=NL"
if "!os_locale!"=="813" set "detected_language=NL"

if "!os_locale!"=="415" set "detected_language=PL"

exit /b
